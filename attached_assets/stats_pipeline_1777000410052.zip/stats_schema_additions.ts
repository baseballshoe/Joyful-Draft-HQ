// ── ADD THIS TO THE BOTTOM OF shared/schema.ts ───────────────────────────
//
// Advanced player stats from pybaseball (Statcast + FanGraphs).
// Populated by the nightly GitHub Actions job.
//
// After pasting, run: npm run db:push

import { pgTable, text, integer, real, timestamp, serial } from "drizzle-orm/pg-core";

// ── Player IDs across systems ────────────────────────────────────────────
// Links a player in our DB to their MLBAM / FanGraphs / Yahoo IDs for
// joining with advanced stats data.
export const playerIds = pgTable("player_ids", {
  id:             serial("id").primaryKey(),
  playerId:       integer("player_id").notNull(),  // FK to players.id
  mlbamId:        integer("mlbam_id"),             // Baseball Savant / MLB ID
  fangraphsId:    integer("fangraphs_id"),         // FanGraphs ID
  bbrefId:        text("bbref_id"),                // Baseball Reference ID
  yahooPlayerKey: text("yahoo_player_key"),        // e.g. "423.p.10835"
  nameNormalized: text("name_normalized"),         // for fuzzy matching
  updatedAt:      timestamp("updated_at").defaultNow(),
});

// ── Batter stats (season-to-date) ────────────────────────────────────────
export const batterStats = pgTable("batter_stats", {
  id:          serial("id").primaryKey(),
  playerId:    integer("player_id").notNull(),
  season:      integer("season").notNull(),

  // Basic counting stats
  games:       integer("games"),
  atBats:      integer("at_bats"),
  plateApps:   integer("plate_apps"),
  runs:        integer("runs"),
  hits:        integer("hits"),
  doubles:     integer("doubles"),
  triples:     integer("triples"),
  homeRuns:    integer("home_runs"),
  rbi:         integer("rbi"),
  stolenBases: integer("stolen_bases"),
  caughtStealing: integer("caught_stealing"),
  walks:       integer("walks"),
  strikeouts:  integer("strikeouts"),

  // Rate stats
  avg:         real("avg"),
  obp:         real("obp"),
  slg:         real("slg"),
  ops:         real("ops"),
  iso:         real("iso"),
  babip:       real("babip"),
  wOBA:        real("w_oba"),
  wRCplus:     real("wrc_plus"),

  // Advanced / Statcast
  barrelPct:   real("barrel_pct"),       // barrels per batted ball event
  hardHitPct:  real("hard_hit_pct"),     // 95+ mph exit velocity
  avgExitVelo: real("avg_exit_velo"),
  maxExitVelo: real("max_exit_velo"),
  avgLaunchAngle: real("avg_launch_angle"),
  xBA:         real("xba"),              // expected batting average
  xSLG:        real("xslg"),             // expected slugging
  xwOBA:       real("xwoba"),            // expected wOBA

  // Plate discipline
  chasePct:    real("chase_pct"),        // swing% on pitches out of zone
  whiffPct:    real("whiff_pct"),        // swing & miss rate
  contactPct:  real("contact_pct"),
  zoneContactPct: real("zone_contact_pct"),

  // Splits
  sprintSpeed: real("sprint_speed"),     // feet/second

  dataSource:  text("data_source"),      // 'fangraphs' | 'savant' | 'merged'
  fetchedAt:   timestamp("fetched_at").defaultNow(),
});

// ── Pitcher stats (season-to-date) ───────────────────────────────────────
export const pitcherStats = pgTable("pitcher_stats", {
  id:          serial("id").primaryKey(),
  playerId:    integer("player_id").notNull(),
  season:      integer("season").notNull(),

  // Basic counting stats
  games:       integer("games"),
  gamesStarted: integer("games_started"),
  wins:        integer("wins"),
  losses:      integer("losses"),
  saves:       integer("saves"),
  holds:       integer("holds"),
  qualityStarts: integer("quality_starts"),
  inningsPitched: real("innings_pitched"),
  hitsAllowed: integer("hits_allowed"),
  earnedRuns:  integer("earned_runs"),
  walksAllowed: integer("walks_allowed"),
  strikeoutsPitched: integer("strikeouts_pitched"),
  homerunsAllowed: integer("homeruns_allowed"),

  // Rate stats
  era:         real("era"),
  whip:        real("whip"),
  kPer9:       real("k_per_9"),
  bbPer9:      real("bb_per_9"),
  kRate:       real("k_rate"),           // K%
  bbRate:      real("bb_rate"),          // BB%
  kMinusBB:    real("k_minus_bb"),       // K% - BB%

  // Advanced
  fip:         real("fip"),
  xFIP:        real("x_fip"),
  siera:       real("siera"),
  xERA:        real("x_era"),
  war:         real("war"),

  // Statcast — pitch profile
  avgFastballVelo: real("avg_fastball_velo"),
  maxFastballVelo: real("max_fastball_velo"),
  spinRate:    real("spin_rate"),

  // Batted ball against
  barrelPctAgainst: real("barrel_pct_against"),
  hardHitPctAgainst: real("hard_hit_pct_against"),
  xwOBAagainst: real("xwoba_against"),
  xBAagainst:  real("xba_against"),

  // Plate discipline induced
  cswPct:      real("csw_pct"),          // called strike + whiff %
  swStrikePct: real("sw_strike_pct"),    // swinging strike %
  chasePctInduced: real("chase_pct_induced"),
  zonePct:     real("zone_pct"),

  dataSource:  text("data_source"),
  fetchedAt:   timestamp("fetched_at").defaultNow(),
});

export type PlayerIds    = typeof playerIds.$inferSelect;
export type BatterStats  = typeof batterStats.$inferSelect;
export type PitcherStats = typeof pitcherStats.$inferSelect;

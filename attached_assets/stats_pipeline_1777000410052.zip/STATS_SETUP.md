# Stats Pipeline Setup Guide

This directory contains the pybaseball-powered stats puller that runs on
GitHub Actions and writes advanced stats to your Postgres database.

## Setup (one-time)

### 1. Add schema tables

Copy `stats_schema_additions.ts` contents into the bottom of
`shared/schema.ts`, then in Replit shell run:

```bash
npm run db:push
```

This creates three new tables in Postgres: `player_ids`, `batter_stats`,
`pitcher_stats`.

### 2. Add Python files to your repo

Place these files in your repo (create `scripts/` folder if it doesn't
exist):

- `scripts/pull_stats.py`
- `scripts/requirements.txt`

### 3. Add GitHub Actions workflow

Place this file in your repo:

- `.github/workflows/pull-stats.yml`

### 4. Add your Postgres connection string as a GitHub secret

In your GitHub repo:

1. Go to Settings → Secrets and variables → Actions
2. Click "New repository secret"
3. Name: `DATABASE_URL`
4. Value: your Postgres connection string from Replit
   (same one you already use — find it in Replit Secrets as
   `DATABASE_URL`)
5. Click "Add secret"

### 5. Commit and push

Commit all these files and push to GitHub. The workflow will now:
- Run automatically every night at 9 AM UTC
- Pull all current-season batter and pitcher stats from FanGraphs
- Match players to your DB and write stats to `batter_stats` / `pitcher_stats`

### 6. Trigger a manual test run

Go to your GitHub repo → Actions tab → "Pull Stats" → "Run workflow"

You'll see a log showing:
- How many players were matched to MLBAM/FanGraphs IDs
- How many batter and pitcher rows were written
- Any unmatched players (usually 5-15 due to name variations)

## What this gives you

Every player in your DB who's active in MLB will have rich stats including:

### Batters
Basic: G, AB, PA, R, H, 2B, 3B, HR, RBI, SB, CS, BB, K
Rate: AVG, OBP, SLG, OPS, ISO, BABIP, wOBA, wRC+
Statcast: Barrel%, HardHit%, EV, maxEV, LA, xBA, xSLG, xwOBA
Discipline: Chase%, Whiff%, Contact%, Z-Contact%
Speed: Sprint Speed

### Pitchers
Basic: G, GS, W, L, SV, HLD, QS, IP, H, ER, BB, K, HR
Rate: ERA, WHIP, K/9, BB/9, K%, BB%, K-BB%
Advanced: FIP, xFIP, SIERA, xERA, WAR
Pitch profile: FB velo, max FB velo, spin rate
Against: Barrel%, HardHit%, xwOBA, xBA
Discipline: CSW%, SwStr%, Chase%, Zone%

## Why FanGraphs (not Statcast directly)

We pull from FanGraphs because:
1. It's already a combined source — includes both Statcast metrics AND
   calculated metrics like wRC+, FIP, SIERA
2. Single request returns all players at once (much faster than per-player Savant)
3. Includes advanced metrics not available from Savant raw data

## When things break

### "DATABASE_URL not set"
You forgot step 4 — add the secret in GitHub.

### Players missing from stats tables
Some players won't match because:
- They're minor league (not in Chadwick register yet)
- Name variations (Luis Garcia vs Luis García)
The job logs unmatched names — manual fixes can go in `player_ids` table.

### Workflow not running
GitHub pauses scheduled workflows on repos with no commits for 60+ days.
Just push any change to wake it back up.

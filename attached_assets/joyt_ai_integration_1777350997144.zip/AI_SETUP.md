# JOYT AI Integration — Setup Guide

This adds the AI assistant to your JOYT app. After setup you'll have:
- A floating "Ask 🤖" button in the bottom-right of every page
- A slide-out sidebar with streaming AI responses
- Conversation history that persists across page navigation
- Suggested prompts based on which page the user is on
- Privacy-scoped data (per-user, ready for multi-user later)
- Usage tracking for future tier enforcement

## Files in this zip

- `joyt_ai_schema.ts` — Database schema additions
- `joyt_ai_service.ts` — Backend AI service (Anthropic integration)
- `joyt_ai_routes.ts` — API endpoints
- `joyt_ai_component.tsx` — Frontend sidebar component
- `STATS_SETUP.md` — This guide

## Setup (one-time)

### 1. Install the Anthropic SDK

In Replit shell:
```bash
npm install @anthropic-ai/sdk
```

### 2. Add schema tables

Copy `joyt_ai_schema.ts` contents into the bottom of `shared/schema.ts`,
then run:
```bash
npm run db:push
```

This creates two new tables: `ai_conversations` and `ai_usage`.

### 3. Add the AI service

Place `joyt_ai_service.ts` in your repo at:
- `server/ai.ts`

### 4. Add the routes

In `server/routes.ts`:

a) Add these imports at the top with the other imports:
```typescript
import * as ai from './ai';
import { aiConversations } from '@shared/schema';
```

b) Paste the contents of `joyt_ai_routes.ts` inside `registerRoutes()`,
   just before the final `return httpServer;` line.

### 5. Add the component

Place `joyt_ai_component.tsx` in your repo at:
- `client/src/components/ask-ai.tsx`

### 6. Mount the component on the dashboard

Open `client/src/pages/dashboard.tsx`, add the import:
```typescript
import AskAI from '@/components/ask-ai';
```

Then add the component anywhere in your dashboard JSX (recommended:
just before the closing tag of the outer container):
```tsx
<AskAI pageContext="dashboard" />
```

The component renders its own floating button + sidebar — it doesn't
take any layout space, so it works anywhere.

### 7. Verify ANTHROPIC_API_KEY is set

You should already have this in Replit Secrets from earlier setup.
Verify with:
```bash
echo $ANTHROPIC_API_KEY
```

Should show your `sk-ant-api03-...` key.

### 8. Restart your app

In Replit, restart the app (or it should auto-reload with package changes).

## Testing

1. Navigate to the dashboard
2. You should see a pink "🤖 Ask" button in the bottom right
3. Click it — sidebar slides in from the right
4. You should see suggested prompts
5. Click a suggestion or type a question
6. Watch the response stream in real-time

## Adding the AI to other pages

Same component, different `pageContext` value:

```tsx
// On waiver page:
<AskAI pageContext="waiver" />

// On roster page:
<AskAI pageContext="roster" />

// On player detail page (with extra context):
<AskAI pageContext="player" contextData={{ playerId: 123 }} />
```

The component automatically loads suggested prompts for the page,
and the AI service sees the page context in its prompt for relevant answers.

## Architecture overview

```
┌─────────────────────────────────────────────────────────┐
│ Frontend (React)                                        │
│  - <AskAI pageContext="..." /> — floating sidebar       │
│  - Streams responses via Server-Sent Events             │
│  - Saves session in sessionStorage                      │
└──────────────────┬──────────────────────────────────────┘
                   │ POST /api/ai/ask (SSE stream)
                   ▼
┌─────────────────────────────────────────────────────────┐
│ Backend (Express)                                       │
│  - server/ai.ts: askAIStream() generator                │
│  - Builds system prompt (scope, safety guardrails)      │
│  - Pulls user data (roster, stats, league) — by userId  │
│  - Calls anthropic.messages.stream()                    │
│  - Saves history + logs metadata                        │
└──────────────────┬──────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────┐
│ Database (Postgres / Neon)                              │
│  - ai_conversations: chat history (by user/session)     │
│  - ai_usage: metadata for rate limits / cost tracking   │
│  - players, batter_stats, pitcher_stats, yahoo_*        │
└─────────────────────────────────────────────────────────┘
```

## Privacy & safety guardrails (already built in)

- ✅ All DB queries scoped by `userId` — no cross-user leakage
- ✅ System prompt limits scope to fantasy baseball
- ✅ Off-topic questions get redirected
- ✅ No medical/legal/financial advice
- ✅ Stats cited as evidence, not displayed as leaderboards
- ✅ Usage logging captures metadata only (no content in usage table)
- ✅ Conversation history isolated per session

## Cost monitoring

In Anthropic Console (console.anthropic.com):
- Set spending limits (recommended: $50/month while testing)
- Set email alerts at 50%/80%/100% of limit
- Monitor usage in the dashboard

In your app database (`ai_usage` table) you can see:
- Cost estimates per request
- Token counts
- Response times
- Success/failure rates

Query example:
```sql
SELECT
  date_trunc('day', created_at) as day,
  COUNT(*) as requests,
  SUM(tokens_in) as total_in,
  SUM(tokens_out) as total_out,
  SUM(cost_estimate) as estimated_cost_usd
FROM ai_usage
GROUP BY day
ORDER BY day DESC;
```

## When things break

### "ANTHROPIC_API_KEY not set"
Add to Replit Secrets, restart shell.

### Streaming doesn't work / connection drops
Check that your hosting supports SSE (Replit does).

### "Cannot find module '@anthropic-ai/sdk'"
Run `npm install @anthropic-ai/sdk` in Replit shell.

### AI gives generic answers (not using your data)
Make sure you have:
- Yahoo league synced (from earlier setup)
- Players marked as "Mine" (status='mine')
- Stats pipeline has run (check `batter_stats` / `pitcher_stats` tables)

### Rate limit errors
You're hitting Anthropic's per-minute rate limit. Wait a moment.
Or reduce parallel requests.

## What's next

After this is working, future enhancements:
- Drop the component on more pages (waiver, roster, players, etc.)
- Add per-tier rate limits when you build user accounts
- Add multi-model routing (Haiku for simple queries, Opus for premium)
- Build a "daily briefing" AI card on the dashboard
- Add player-specific "Ask about this player" buttons

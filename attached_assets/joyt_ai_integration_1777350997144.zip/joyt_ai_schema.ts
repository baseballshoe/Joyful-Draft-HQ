// ── ADD THIS TO THE BOTTOM OF shared/schema.ts ──────────────────────────
//
// AI conversation history + usage tracking.
//
// Two tables:
//  - ai_conversations: stores chat history per session (per user when we
//    add multi-user). Cleared when user starts "new chat" or session ends.
//  - ai_usage: tracks API calls for rate limiting, cost monitoring, and
//    future tier enforcement. Privacy-safe (metadata only, no content).
//
// After pasting, run: npm run db:push

import { pgTable, text, integer, real, timestamp, serial, boolean } from "drizzle-orm/pg-core";

// ── AI Conversations (chat history) ─────────────────────────────────────
export const aiConversations = pgTable("ai_conversations", {
  id:          serial("id").primaryKey(),
  userId:      integer("user_id").default(1),         // Always 1 for single-user; ready for multi-user
  sessionId:   text("session_id").notNull(),           // Groups messages in a "session" — frontend generates UUID
  role:        text("role").notNull(),                 // 'user' | 'assistant'
  content:     text("content").notNull(),              // The actual message text
  pageContext: text("page_context"),                   // 'dashboard' | 'roster' | 'waiver' | etc — page user was on
  modelUsed:   text("model_used"),                     // 'claude-haiku-4-5' | 'claude-sonnet-4-6' | etc
  tokensIn:    integer("tokens_in"),                   // Token count for this message (assistant rows only)
  tokensOut:   integer("tokens_out"),
  createdAt:   timestamp("created_at").defaultNow(),
});

// ── AI Usage Tracking (privacy-safe metadata) ───────────────────────────
// We log every API call's metadata for:
//  - Rate limiting (e.g., free tier: 5 questions/week)
//  - Cost monitoring (catch runaway usage)
//  - Tier enforcement (paid users get more)
//
// IMPORTANT: We log metadata only. No question content, no response content.
// This protects user privacy even if our logs get exposed.
export const aiUsage = pgTable("ai_usage", {
  id:           serial("id").primaryKey(),
  userId:       integer("user_id").default(1),
  sessionId:    text("session_id"),
  pageContext:  text("page_context"),
  modelUsed:    text("model_used"),
  tokensIn:     integer("tokens_in").default(0),
  tokensOut:    integer("tokens_out").default(0),
  costEstimate: real("cost_estimate"),                 // In USD
  responseMs:   integer("response_ms"),                // Latency
  success:      boolean("success").default(true),
  errorType:    text("error_type"),                    // If failed: 'rate_limit' | 'api_error' | 'invalid_input' | etc
  createdAt:    timestamp("created_at").defaultNow(),
});

export type AiConversation = typeof aiConversations.$inferSelect;
export type AiUsage         = typeof aiUsage.$inferSelect;

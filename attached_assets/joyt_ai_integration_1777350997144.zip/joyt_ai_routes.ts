// ── ADD THESE ROUTES TO server/routes.ts ─────────────────────────────────
//
// 1. Add this import at the top of server/routes.ts (with other imports):
//
//    import * as ai from './ai';
//    import { aiConversations } from '@shared/schema';
//
// 2. Paste the route handlers below INSIDE your registerRoutes() function,
//    just before the final `return httpServer;` line.
//
// ─────────────────────────────────────────────────────────────────────────

// ── AI: streaming chat endpoint (Server-Sent Events) ────────────────────
// POST /api/ai/ask
// Body: { sessionId, question, pageContext, contextData? }
//
// Returns a streaming SSE response. Each chunk is JSON like:
//   { "type": "text", "content": "Hello" }
//   { "type": "done", "content": "" }
//   { "type": "error", "content": "Error message" }
app.post('/api/ai/ask', async (req, res) => {
  const { sessionId, question, pageContext, contextData } = req.body;

  if (!sessionId || !question || !pageContext) {
    return res.status(400).json({
      message: 'sessionId, question, and pageContext are required',
    });
  }

  // Single-user for now — userId always 1. When we add auth, this becomes
  // the authenticated user's ID. The downstream AI service is already
  // scoped by userId for privacy.
  const userId = 1;

  // Set up SSE headers
  res.writeHead(200, {
    'Content-Type':       'text/event-stream',
    'Cache-Control':      'no-cache',
    'Connection':         'keep-alive',
    'X-Accel-Buffering':  'no',  // Disable nginx buffering
  });

  // Helper to send SSE chunks
  const send = (data: any) => {
    res.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  try {
    // Stream from Claude
    for await (const chunk of ai.askAIStream({
      userId,
      sessionId,
      question,
      pageContext,
      contextData,
    })) {
      send(chunk);
      if (chunk.type === 'done' || chunk.type === 'error') break;
    }
  } catch (err: any) {
    console.error('AI route error:', err);
    send({ type: 'error', content: err.message ?? 'Server error' });
  } finally {
    res.end();
  }
});

// ── AI: get conversation history for a session ──────────────────────────
app.get('/api/ai/history', async (req, res) => {
  const sessionId = req.query.sessionId as string;
  if (!sessionId) {
    return res.status(400).json({ message: 'sessionId required' });
  }

  const userId = 1;

  try {
    const history = await ai.getConversationHistory(userId, sessionId);
    res.json(history.map(h => ({
      id:        h.id,
      role:      h.role,
      content:   h.content,
      createdAt: h.createdAt,
    })));
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// ── AI: clear session (start a new chat) ─────────────────────────────────
app.delete('/api/ai/session', async (req, res) => {
  const sessionId = req.query.sessionId as string;
  if (!sessionId) {
    return res.status(400).json({ message: 'sessionId required' });
  }

  const userId = 1;

  try {
    await ai.clearSession(userId, sessionId);
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// ── AI: get suggested prompts for a page ────────────────────────────────
app.get('/api/ai/suggestions', (req, res) => {
  const pageContext = (req.query.pageContext as string) ?? 'dashboard';
  const prompts = ai.getSuggestedPrompts(pageContext);
  res.json({ pageContext, prompts });
});

// ── AI: get usage stats (for future tier enforcement / analytics) ───────
app.get('/api/ai/usage', async (_req, res) => {
  const userId = 1;

  try {
    // Simple stats — total questions this week
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const recent = await db
      .select()
      .from(aiConversations)
      .where(and(
        eq(aiConversations.userId, userId),
        eq(aiConversations.role, 'user'),
      ));

    const recentInWindow = recent.filter(r =>
      r.createdAt && new Date(r.createdAt) > oneWeekAgo
    );

    res.json({
      questionsThisWeek: recentInWindow.length,
      questionsAllTime:  recent.length,
    });
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

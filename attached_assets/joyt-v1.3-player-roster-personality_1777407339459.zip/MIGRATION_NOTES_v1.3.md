# JOYT v1.3 — Player Roster Seed + Personality Refinement

This release fixes the "Coach has no stats for newly-debuted players"
problem (Parker Messick, Noah Schultz, etc.) and refines Coach's tone
to be warmer and more situationally aware.

## What this adds

- **MLB Stats API player roster seed:** Nightly GitHub Action pulls the
  complete active MLB player list, inserts missing players, and
  populates `player_ids` with MLBAM IDs. This unblocks the Savant stats
  pipeline for players the static draft CSV missed.
- **Players abstraction layer (`server/external/players.ts`):**
  Forward-looking interface for runtime player lookups by MLBAM ID or
  name. Same commercial-readiness pattern as `schedule.ts`.
- **Personality v3 refinement:** Adds rules for warmth (tease, don't
  lecture), situational awareness (check the wire before calling
  players replaceable), pair-diagnosis-with-direction (always include
  next move or honest "no upgrade"), and response-mode calibration
  (rec vs analysis vs commiseration vs banter).

## What this fixes

Parker Messick's situation specifically:
- Messick wasn't in our `players` table because he debuted Aug 2025,
  after the static CSV seed
- Yahoo's roster sync DID add him to `players` (he's on Josh's bench)
  but didn't populate `player_ids` with his MLBAM ID
- Chadwick Register in `pull_stats.py` may not match him yet (lags for
  recent debuts)
- Result: stats pipeline can't link Messick → his Savant stats → our DB
- Coach correctly reports "no stats" — the data IS missing

After v1.3:
- `pull_players.py` runs nightly, pulls Messick from MLB Stats API,
  populates `player_ids` with his MLBAM ID directly
- Next `pull_stats.py` run, Savant matches by MLBAM ID, fills in his
  stats
- Coach now has Messick's actual data

Same fix applies to every recent callup, mid-season trade, and rookie.

## Pre-flight checks

- [ ] v1.0 + v1.1 + v1.1a + v1.2 are all deployed
- [ ] No new Replit secrets needed
- [ ] GitHub repo secret `DATABASE_URL` is set (it already is for the
  existing `pull-stats.yml` workflow)
- [ ] You have GitHub Actions enabled for the repo

## File inventory

```
.github/workflows/
  pull-players.yml           [NEW]      — daily 06:00 UTC cron

scripts/
  pull_players.py            [NEW]      — MLB Stats API → players +
                                            player_ids + player_status

server/external/
  players.ts                 [NEW]      — runtime lookup interface
  players-impl.ts            [NEW]      — MLB Stats API runtime impl

server/
  yahoo-cache.ts             [REPLACE]  — adds mlb:player:* and
                                            mlb:players:active:* TTL
                                            prefixes (backward compat)

server/coach/
  personality.ts             [REPLACE]  — v3 refinement (warmth,
                                            situational awareness,
                                            diagnosis-with-direction,
                                            response-mode calibration)
```

**Total: 6 files, ~880 lines.**

## Migration steps

### Step 1 — Drop in the new files

- `scripts/pull_players.py` (NEW)
- `.github/workflows/pull-players.yml` (NEW)
- `server/external/players.ts` (NEW)
- `server/external/players-impl.ts` (NEW)

### Step 2 — Replace existing files

- `server/yahoo-cache.ts` (adds 2 new prefix TTLs; backward compatible)
- `server/coach/personality.ts` (v3 refinement)

### Step 3 — No schema changes, no routes changes

This release only writes to existing tables (`players`, `player_ids`,
`player_status`, `yahoo_cache`). No `npm run db:push` needed.

### Step 4 — Trigger the first player roster pull manually

After deploying:
1. Go to GitHub → Actions tab → "Pull MLB players" workflow
2. Click "Run workflow" → main branch → Run workflow
3. Watch the run logs. Should complete in under a minute. Expected
   output:
   ```
   Fetching MLB players for 2026...
     Got ~1500 player records
     Filtered to ~1500 valid players
     Existing: N MLBAM-mapped, M name-mapped
     Inserting K new players...
     Upserting ~1500 player_ids rows...
     Upserting ~1500 player_status rows...
   Done in ~30s
     Total from API:     ~1500
     Matched by MLBAM:   N
     Matched by name:    M
     Newly inserted:     K
   ```
4. The number "Newly inserted" tells you how many players the static
   CSV missed. For a fresh deploy this might be a few dozen
   (rookies, callups, recent additions); subsequent runs should show
   small numbers (just true new debuts).

### Step 5 — Re-run pull_stats.py to backfill stats for new players

Once the players are in the DB with their MLBAM IDs, manually trigger
the existing stats workflow:
1. GitHub → Actions → "Pull Stats" workflow → Run workflow
2. Watch the logs. The "Matched X, unmatched Y" log line in
   `build_player_id_map` should now show fewer unmatched.
3. Savant batter/pitcher stats should now flow for newly-added players.

### Step 6 — Smoke tests

```bash
# 1. Verify pull_players.py inserted Messick
psql $DATABASE_URL -c "
  SELECT p.id, p.name, p.team, p.pos_display, pi.mlbam_id, ps.current_team
  FROM players p
  LEFT JOIN player_ids pi    ON p.id = pi.player_id
  LEFT JOIN player_status ps ON p.id = ps.player_id
  WHERE p.name ILIKE '%messick%';
"
# Expect: 1 row with mlbam_id = 800048 and current_team = CLE

# 2. After pull_stats.py runs, verify Messick has pitcher stats
psql $DATABASE_URL -c "
  SELECT player_id, season, games_started, era, whip, xERA, fip
  FROM pitcher_stats
  WHERE player_id = (SELECT id FROM players WHERE name ILIKE '%messick%')
    AND season = 2026;
"
# Expect: 1 row with current 2026 season stats

# 3. Open Coach, ask: "what about Parker Messick?"
#    Expect: Coach references his actual ERA/xERA/CSW% from the data,
#    not "I have zero stats for him". Tone should be warmer than v1.2.
```

## What to expect from the personality refinement

Before v1.3 (lecture energy):
> "You're 11th place. You can't afford to speculate this hard."
> "That's the problem with your roster construction."

After v1.3 (tease energy):
> "Look at us trying to recreate the entire Cleveland farm system on
>  one bench. I admire the conviction."
> "Pasquantino's already doing nothing — these prospect stashes are
>  taking up space your bats could use."

Same content, friend voice instead of corrective parent voice.

Other expected changes:
- Coach checks the actual wire before calling players "replaceable"
- Coach pairs every diagnosis with a recommendation, soft hook, OR
  honest "no upgrade available"
- Coach commiserates when the user is venting before getting
  constructive
- No more bold mini-headers (`**The scoreboard:**`) on broad questions

## Rollback

If anything misbehaves:
1. **Personality only:** revert `server/coach/personality.ts` to v1.2.
   The v3 changes are isolated to that file.
2. **Disable nightly player pull:** disable the GitHub Action via
   the Actions UI. Existing data stays put; nothing in the app
   depends on the daily run.
3. **Remove abstraction layer:** delete `server/external/players.ts`
   and `players-impl.ts`. Nothing else imports from them yet.

## Pre-commercial swap reminder

`scripts/pull_players.py` and `server/external/players-impl.ts` both
use MLB Stats API which is non-commercial-only. **Before charging
users:**

1. Choose a licensed provider (SportsDataIO recommended for indie
   commercial)
2. Rewrite `pull_players.py` to call the licensed provider's roster
   endpoint instead of MLB Stats API. The DB writes don't change.
3. Rewrite `server/external/players-impl.ts` against the same provider
4. Update commercial-readiness docs

Same swap pattern as the schedule layer in v1.2. One file per data
type.

## What's deferred

- Question-intent detection in `categorizer.ts` (skipped per user call;
  the personality file alone handles intent calibration via the model's
  reasoning)
- Admin dashboard UI (still waiting on more telemetry data)
- 6 new pages (Season Dashboard, Matchup, Waivers, Standings,
  Transactions, News)

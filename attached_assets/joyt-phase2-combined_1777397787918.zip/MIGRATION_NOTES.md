# JOYT Phase 2 — Combined Foundation Pack (v1.0 + v1.1 + v1.1a)

This pack bundles three deployment phases into one ZIP:

- **v1.0 — Foundation:** Yahoo cache layer, Coach personality (sport-agnostic), full Yahoo data in AI context, auto-sync infrastructure.
- **v1.1 — Efficiency:** Prompt caching (3-block split), output cap (1500 tokens), conversation history truncation (last 8 turns), lazy-loading of other teams' rosters.
- **v1.1a — Telemetry foundation:** `coach_interactions` table, regex-based question categorizer, 90-day retention job, admin-auth middleware, admin endpoints (data only — UI ships in v1.1b).

**Dashboard UI (v1.1b)** ships in a separate pack after telemetry has baked for a few days.

---

## Pre-flight checks

Before unzipping, verify on Replit:

- [ ] Node 18+ runtime
- [ ] PostgreSQL connected (DATABASE_URL set)
- [ ] These secrets exist: `YAHOO_CLIENT_ID`, `YAHOO_CLIENT_SECRET`, `APP_BASE_URL`, `ANTHROPIC_API_KEY`
- [ ] **NEW SECRET to add:** `ADMIN_USER_IDS=<your-user-id>` — this is what gates `/api/admin/*` routes. Set it to your numeric user ID (e.g. `1` if you're the only user). Comma-separated for multiple admins later.
- [ ] (Optional) `DISABLE_CACHE=1` if you want to disable prompt caching during local development. Leave unset in production.

---

## File inventory

```
shared/
  schema-additions.ts             [MERGE]   yahoo_cache + coach_interactions tables

server/
  yahoo-cache.ts                  [NEW]     TTL-aware cache layer
  yahoo.ts                        [REPLACE] adds parsed methods, preserves all existing exports
  ai.ts                           [REPLACE] caching + telemetry + history truncation
  routes-phase2-additions.ts      [REFERENCE] route bodies to merge into routes.ts

server/coach/
  personality.ts                  [NEW]     sport-agnostic personality + brevity guidance
  baseball.ts                     [NEW]     baseball sport pack
  context.ts                      [NEW]     3-block context builder + lazy team loading
  categorizer.ts                  [NEW]     regex question bucketing
  telemetry.ts                    [NEW]     coach_interactions writer + cost calculator
  retention.ts                    [NEW]     90-day cleanup scheduler

server/middleware/
  admin-auth.ts                   [NEW]     requireAdmin middleware

client/src/hooks/
  use-yahoo-data.ts               [NEW]     TanStack Query hooks for cache-aware endpoints

client/src/components/
  ask-ai.tsx                      [REPLACE] full Coach rebrand
```

---

## Migration steps (DO IN ORDER)

### Step 1 — Schema migration

1. Open `shared/schema-additions.ts` from this pack.
2. The file imports `boolean`, `integer`, `real`, `index` from `drizzle-orm/pg-core`. **Make sure your existing `shared/schema.ts` import line includes all of these.** If your schema's import is missing any, add them.
3. Append the two table definitions (`yahooCache` and `coachInteractions`) to the bottom of `shared/schema.ts`.
4. Read the trailing comment block in `schema-additions.ts` about the `is_admin` column — for v1.1a we use env var, but a note marks where to add the column when you build a real users table in Phase 2.
5. Run:

   ```bash
   npm run db:push
   ```

6. Verify in Postgres: tables `yahoo_cache` and `coach_interactions` exist.

### Step 2 — Drop in server files

These are one-to-one drop-ins. Copy from the pack to the corresponding paths:

- `server/yahoo-cache.ts` (NEW)
- `server/yahoo.ts` (REPLACES — keeps all existing exports; OAuth + sync-roster keep working)
- `server/coach/personality.ts` (NEW — create the `coach/` directory)
- `server/coach/baseball.ts` (NEW)
- `server/coach/context.ts` (NEW)
- `server/coach/categorizer.ts` (NEW)
- `server/coach/telemetry.ts` (NEW)
- `server/coach/retention.ts` (NEW)
- `server/middleware/admin-auth.ts` (NEW — create the `middleware/` directory)
- `server/ai.ts` (REPLACES — keeps same exports; routes.ts AI routes need zero changes)

### Step 3 — Routes merge (the careful step)

`server/routes-phase2-additions.ts` is **NOT a drop-in**. It's a reference file with route bodies. Merge them into your existing `server/routes.ts`:

1. **Add imports** at the top of `routes.ts`:

   ```typescript
   import * as yahooCache from './yahoo-cache';
   import { requireAdmin } from './middleware/admin-auth';
   import { coachInteractions } from '@shared/schema';
   import { gte, desc, sql } from 'drizzle-orm'; // add gte, desc, sql if missing
   ```

2. **Replace** these existing endpoints with the cache-aware versions in the additions file:
   - `GET /api/yahoo/standings`
   - `GET /api/yahoo/scoreboard`
   - `GET /api/yahoo/waiver-wire`

3. **Add** these new Yahoo endpoints from the additions file:
   - `GET  /api/yahoo/settings`
   - `GET  /api/yahoo/rosters`
   - `GET  /api/yahoo/transactions`
   - `GET  /api/yahoo/all`
   - `GET  /api/yahoo/cache-status`
   - `POST /api/yahoo/refresh`

4. **Add** these admin endpoints (all use `requireAdmin` middleware):
   - `GET /api/admin/coach/summary`
   - `GET /api/admin/coach/trend`
   - `GET /api/admin/coach/buckets`
   - `GET /api/admin/coach/pages`
   - `GET /api/admin/coach/expensive`
   - `GET /api/admin/coach/users`

5. After merging, delete `server/routes-phase2-additions.ts` from your repo — it's reference only, not meant to be deployed.

### Step 4 — Wire the retention scheduler

In your server entrypoint (typically `server/index.ts` or wherever the express app boots), add this **after** the app starts listening:

```typescript
import { startRetentionScheduler } from './coach/retention';

// ...inside your startup code, after app.listen(...)
startRetentionScheduler();
```

This kicks off the 90-day cleanup job (runs once after 30s, then every 6 hours).

### Step 5 — Drop in client files

- `client/src/hooks/use-yahoo-data.ts` (NEW — create the `hooks/` directory if needed)
- `client/src/components/ask-ai.tsx` (REPLACES — full Coach rebrand, default export name `AskAI` unchanged so page imports still work)

### Step 6 — Breaking change check

The standings, scoreboard, and waiver-wire endpoints now wrap responses in `{ data, meta }` envelopes (the new client hooks already handle this). If any **existing** page parses these endpoints' raw response, update it.

Quick grep to find them:

```bash
grep -rn "useQuery.*standings\|useQuery.*scoreboard\|useQuery.*waiver-wire" client/src
```

For each match, read `response.data` instead of `response`.

### Step 7 — Smoke tests

Run these in order. Stop and fix anything that fails before continuing.

```bash
# 1. Schema migrated
psql $DATABASE_URL -c "SELECT 1 FROM yahoo_cache LIMIT 1;"
psql $DATABASE_URL -c "SELECT 1 FROM coach_interactions LIMIT 1;"

# 2. Cache layer alive
curl https://drafthq.replit.app/api/yahoo/cache-status

# 3. Cache populates fresh
curl https://drafthq.replit.app/api/yahoo/settings
# Expect: { "data": {...}, "meta": { "fresh": true, "ageSec": 0, ... } }

# 4. Cache returns hit on second call
curl https://drafthq.replit.app/api/yahoo/settings
# Expect: meta.ageSec > 0, meta.fresh still true (within TTL)

# 5. Force refresh works
curl https://drafthq.replit.app/api/yahoo/settings?force=1
# Expect: meta.ageSec near 0 again

# 6. Bundled endpoint
curl https://drafthq.replit.app/api/yahoo/all | jq 'keys'
# Expect: ["rosters","scoreboard","settings","standings","waiversBat","waiversPit"]

# 7. Admin gating denies non-admin
curl https://drafthq.replit.app/api/admin/coach/summary
# Expect: 404 Not found (because no auth or non-admin)

# 8. Admin gating allows admin (test from a logged-in browser session
#    where your user ID is in ADMIN_USER_IDS)
```

Then test Coach in the browser:

- **9.** Open Coach panel, ask: *"How am I doing in this week's matchup?"*
  - Expect: Response references real Yahoo matchup data, in Coach voice (jargon, brevity, no "Great question!" opener).
- **10.** Same session, ask: *"Should I drop X for Y?"*
  - Expect: Quicker response (~200-400ms faster TTFT) because static prefix is now cached.
- **11.** Check telemetry wrote: `psql $DATABASE_URL -c "SELECT cost_usd, input_tokens, cache_read_tokens, question_bucket FROM coach_interactions ORDER BY id DESC LIMIT 3;"`
  - Expect: Three rows, second turn shows `cache_read_tokens > 0` (cache hit).

If turn 2 shows `cache_read_tokens = 0`, prompt caching isn't working. Check:
- `DISABLE_CACHE` env var is unset
- The system parameter array has `cache_control: { type: 'ephemeral' }` on first two blocks
- Less than 5 minutes elapsed between turn 1 and turn 2 (5-min TTL)

---

## What's running where

| Concern | File | Phase |
|---|---|---|
| Yahoo cache TTLs | `server/yahoo-cache.ts` (`CACHE_TTL_SEC`) | v1.0 |
| Coach personality | `server/coach/personality.ts` | v1.0 |
| Baseball jargon + categories | `server/coach/baseball.ts` | v1.0 |
| Context assembly + cache breakpoints | `server/coach/context.ts` | v1.1 |
| Question categorization | `server/coach/categorizer.ts` | v1.1a |
| Per-turn telemetry | `server/coach/telemetry.ts` | v1.1a |
| 90-day retention | `server/coach/retention.ts` | v1.1a |
| Admin gating | `server/middleware/admin-auth.ts` | v1.1a |
| Output cap (`MAX_TOKENS = 1500`) | `server/ai.ts` | v1.1 |
| History truncation (`MAX_HISTORY_TURNS = 8`) | `server/ai.ts` | v1.1 |
| Prompt caching | `server/ai.ts` (`buildSystemParam`) | v1.1 |

---

## Tuning knobs

If costs run higher or lower than expected:

- **`MAX_TOKENS` in `server/ai.ts`** — drop to 1000 to make Coach even tighter, raise to 2000 if responses feel cut off.
- **`MAX_HISTORY_TURNS` in `server/ai.ts`** — drop to 6 to save more tokens on long sessions, raise to 10 for better long-session coherence.
- **`CACHE_TTL_SEC` in `server/yahoo-cache.ts`** — raise standings/settings TTLs if Yahoo rate limits become an issue, lower scoreboard TTL if matchup data feels stale during games.
- **`RETENTION_DAYS` in `server/coach/retention.ts`** — drop to 30 for tighter privacy, raise to 180 if you want longer trend analysis.
- **`OTHER_TEAMS_RELEVANCE` regex in `server/coach/context.ts`** — this controls when other teams' rosters get included. If Coach starts missing trade context, broaden the regex.

---

## Cost expectations after deploy

Rough monthly cost for personal use after caching kicks in:

| Usage | Turns/month | Monthly cost |
|---|---|---|
| Light (off-season check-ins) | ~120 | ~$2.50 |
| Active in-season | ~300 | ~$6 |
| Draft week + active | ~500 | ~$10 |

Watch the admin dashboard (once v1.1b ships) for your actual cache hit rate. Anything above 20% means caching is working; above 40% means it's working great.

---

## Rollback

If anything in v1.1 / v1.1a breaks production:

1. **Quick disable cache:** Set `DISABLE_CACHE=1` in Replit Secrets, restart. Coach goes back to non-cached behavior. Telemetry still works.
2. **Quick disable telemetry:** Comment out the `recordInteraction` call in `server/ai.ts` (around line 175). Coach keeps working, no rows written.
3. **Full rollback:** Revert `server/ai.ts` and `server/coach/context.ts` to the previous commit. Schema additions are additive (new tables) so no destructive rollback needed.

---

## What's deferred to next session

- **v1.1b — Admin dashboard UI** — the actual `/admin` page consuming the admin endpoints above. Charts, tables, drill-downs.
- **6 new pages** — Season Dashboard, Matchup, Waivers, Standings, Transactions, News. Hooks already shipped this session in `use-yahoo-data.ts`.
- **Sport-agnostic expansion** — `football.ts`, `basketball.ts` packs alongside `baseball.ts` when relevant.
- **Prompt cache analytics deepening** — once you have a week of telemetry data, we can revisit which prefix splits give the best hit rates.

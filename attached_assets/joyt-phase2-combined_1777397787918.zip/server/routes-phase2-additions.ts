// server/routes-phase2-additions.ts
// ─────────────────────────────────────────────────────────────────────
// Phase 2 route additions — to be merged into server/routes.ts.
//
// HOW TO INSTALL:
//   1. At the top of server/routes.ts, add these imports:
//        import * as yahooCache from './yahoo-cache';
//        import { requireAdmin } from './middleware/admin-auth';
//        import { db } from './db';
//        import { coachInteractions } from '@shared/schema';
//        import { sql, gte, desc } from 'drizzle-orm';
//
//   2. Find the section where the existing Yahoo routes are registered
//      (search for `// ── Yahoo: get standings`).
//
//   3. REPLACE the existing endpoints with their cache-aware versions
//      (standings, scoreboard, waiver-wire) and ADD the new ones
//      (settings, rosters, transactions, all, cache-status, refresh).
//
//   4. ADD the admin endpoints from the bottom block of this file.
//      They're stubs returning real data — the v1.1b dashboard UI
//      consumes them.
//
// All Yahoo endpoints accept ?force=1 to bypass cache (useful for the
// user pressing a manual "refresh" button if you ever want one).
//
// Admin endpoints all sit behind requireAdmin middleware. Set
// ADMIN_USER_IDS=<your-user-id> in Replit Secrets to enable.
// ─────────────────────────────────────────────────────────────────────

/*
import type { Express } from 'express';
import { db } from './db';
import { yahooLeague, coachInteractions } from '@shared/schema';
import { eq, gte, desc, sql } from 'drizzle-orm';
import * as yahoo from './yahoo';
import * as yahooCache from './yahoo-cache';
import { requireAdmin } from './middleware/admin-auth';

export function registerYahooPhase2Routes(app: Express, broadcast: (msg: any) => void) {

  // Helper: load the connected league key (or 400 if not connected)
  async function getLeagueKeyOrFail(res: any): Promise<string | null> {
    const [leagueRow] = await db.select().from(yahooLeague).where(eq(yahooLeague.id, 1));
    if (!leagueRow?.leagueKey) {
      res.status(400).json({ message: 'No league connected. Connect Yahoo on the /yahoo page.' });
      return null;
    }
    return leagueRow.leagueKey;
  }

  function force(req: any) { return req.query.force === '1' || req.query.force === 'true'; }

  // ── Settings (cache-aware) ─────────────────────────────────────────────
  app.get('/api/yahoo/settings', async (req, res) => {
    try {
      const leagueKey = await getLeagueKeyOrFail(res);
      if (!leagueKey) return;
      const result = await yahooCache.getCached(
        'settings',
        () => yahoo.getParsedLeagueSettings(leagueKey),
        { force: force(req) },
      );
      res.json({ data: result.data, meta: result.meta });
    } catch (err: any) {
      res.status(400).json({ message: err.message });
    }
  });

  // ── Standings (cache-aware) ────────────────────────────────────────────
  app.get('/api/yahoo/standings', async (req, res) => {
    try {
      const leagueKey = await getLeagueKeyOrFail(res);
      if (!leagueKey) return;
      const result = await yahooCache.getCached(
        'standings',
        () => yahoo.getParsedStandings(leagueKey),
        { force: force(req) },
      );
      res.json({ data: result.data, meta: result.meta });
    } catch (err: any) {
      res.status(400).json({ message: err.message });
    }
  });

  // ── Scoreboard / matchups (cache-aware) ────────────────────────────────
  app.get('/api/yahoo/scoreboard', async (req, res) => {
    try {
      const leagueKey = await getLeagueKeyOrFail(res);
      if (!leagueKey) return;
      const result = await yahooCache.getCached(
        'scoreboard',
        () => yahoo.getParsedScoreboard(leagueKey),
        { force: force(req) },
      );
      res.json({ data: result.data, meta: result.meta });
    } catch (err: any) {
      res.status(400).json({ message: err.message });
    }
  });

  // ── All teams' rosters (cache-aware) ───────────────────────────────────
  app.get('/api/yahoo/rosters', async (req, res) => {
    try {
      const leagueKey = await getLeagueKeyOrFail(res);
      if (!leagueKey) return;
      const result = await yahooCache.getCached(
        'rosters',
        () => yahoo.getAllTeamRosters(leagueKey),
        { force: force(req) },
      );
      res.json({ data: result.data, meta: result.meta });
    } catch (err: any) {
      res.status(400).json({ message: err.message });
    }
  });

  // ── Waiver wire (cache-aware, by position) ─────────────────────────────
  app.get('/api/yahoo/waiver-wire', async (req, res) => {
    try {
      const leagueKey = await getLeagueKeyOrFail(res);
      if (!leagueKey) return;
      const pos = (req.query.pos as string) === 'P' ? 'P' : 'B';
      const cacheKey = `waivers:${pos}`;
      const result = await yahooCache.getCached(
        cacheKey,
        () => yahoo.getWaiverWire(leagueKey, pos, 25),
        { force: force(req) },
      );
      res.json({ data: result.data, meta: result.meta });
    } catch (err: any) {
      res.status(400).json({ message: err.message });
    }
  });

  // ── Transactions (cache-aware) ─────────────────────────────────────────
  app.get('/api/yahoo/transactions', async (req, res) => {
    try {
      const leagueKey = await getLeagueKeyOrFail(res);
      if (!leagueKey) return;
      const result = await yahooCache.getCached(
        'transactions',
        () => yahoo.getRecentTransactions(leagueKey, 25),
        { force: force(req) },
      );
      res.json({ data: result.data, meta: result.meta });
    } catch (err: any) {
      res.status(400).json({ message: err.message });
    }
  });

  // ── Bundled endpoint: everything Coach + dashboard needs in one call ───
  app.get('/api/yahoo/all', async (req, res) => {
    try {
      const leagueKey = await getLeagueKeyOrFail(res);
      if (!leagueKey) return;
      const f = force(req);

      const [settings, standings, scoreboard, rosters, waiverB, waiverP] = await Promise.all([
        yahooCache.getCached('settings',    () => yahoo.getParsedLeagueSettings(leagueKey), { force: f }),
        yahooCache.getCached('standings',   () => yahoo.getParsedStandings(leagueKey),     { force: f }),
        yahooCache.getCached('scoreboard',  () => yahoo.getParsedScoreboard(leagueKey),    { force: f }),
        yahooCache.getCached('rosters',     () => yahoo.getAllTeamRosters(leagueKey),       { force: f }),
        yahooCache.getCached('waivers:B',   () => yahoo.getWaiverWire(leagueKey, 'B', 25),  { force: f }),
        yahooCache.getCached('waivers:P',   () => yahoo.getWaiverWire(leagueKey, 'P', 25),  { force: f }),
      ]);

      res.json({
        settings:    { data: settings.data,    meta: settings.meta },
        standings:   { data: standings.data,   meta: standings.meta },
        scoreboard:  { data: scoreboard.data,  meta: scoreboard.meta },
        rosters:     { data: rosters.data,     meta: rosters.meta },
        waiversBat:  { data: waiverB.data,     meta: waiverB.meta },
        waiversPit:  { data: waiverP.data,     meta: waiverP.meta },
      });

      broadcast({ type: 'yahoo_synced', data: { force: f } });
    } catch (err: any) {
      res.status(400).json({ message: err.message });
    }
  });

  // ── Cache status (debug) ───────────────────────────────────────────────
  app.get('/api/yahoo/cache-status', async (_req, res) => {
    try {
      const status = await yahooCache.getCacheStatus();
      res.json(status);
    } catch (err: any) {
      res.status(400).json({ message: err.message });
    }
  });

  // ── Force refresh (manual override / settings page button) ─────────────
  app.post('/api/yahoo/refresh', async (req, res) => {
    try {
      const key = req.body?.key as string | undefined;
      if (key) {
        await yahooCache.invalidateCache(key);
      } else {
        await yahooCache.invalidateCache();
      }
      res.json({ ok: true, cleared: key ?? 'all' });
      broadcast({ type: 'yahoo_cache_cleared', data: { key: key ?? 'all' } });
    } catch (err: any) {
      res.status(400).json({ message: err.message });
    }
  });

  // ─────────────────────────────────────────────────────────────────────
  // ADMIN ENDPOINTS (v1.1a — feed the v1.1b dashboard)
  // ─────────────────────────────────────────────────────────────────────
  // All admin routes sit behind requireAdmin middleware. Returns 404
  // (not 401) on failure to hide route existence from non-admins.
  //
  // Set in Replit Secrets:
  //   ADMIN_USER_IDS=<your-user-id-as-integer>
  //
  // The dashboard UI ships in a separate v1.1b pack.

  // ── Top-level cost summary ──────────────────────────────────────────────
  // Returns: { today, last7Days, last30Days, monthlyRunRate } in $USD
  app.get('/api/admin/coach/summary', requireAdmin, async (_req, res) => {
    try {
      const now = new Date();
      const startToday   = new Date(now); startToday.setHours(0, 0, 0, 0);
      const start7       = new Date(now.getTime() - 7  * 24 * 3600 * 1000);
      const start30      = new Date(now.getTime() - 30 * 24 * 3600 * 1000);

      const [today]   = await db.select({ total: sql<number>`COALESCE(SUM(${coachInteractions.costUsd}), 0)::float`, turns: sql<number>`COUNT(*)::int` })
        .from(coachInteractions).where(gte(coachInteractions.createdAt, startToday));
      const [last7]   = await db.select({ total: sql<number>`COALESCE(SUM(${coachInteractions.costUsd}), 0)::float`, turns: sql<number>`COUNT(*)::int` })
        .from(coachInteractions).where(gte(coachInteractions.createdAt, start7));
      const [last30]  = await db.select({ total: sql<number>`COALESCE(SUM(${coachInteractions.costUsd}), 0)::float`, turns: sql<number>`COUNT(*)::int` })
        .from(coachInteractions).where(gte(coachInteractions.createdAt, start30));

      // Cache hit rate over last 30 days
      const [cacheStats] = await db.select({
        cacheReads:  sql<number>`COALESCE(SUM(${coachInteractions.cacheReadTokens}), 0)::int`,
        cacheWrites: sql<number>`COALESCE(SUM(${coachInteractions.cacheCreationTokens}), 0)::int`,
        plainInput:  sql<number>`COALESCE(SUM(${coachInteractions.inputTokens}), 0)::int`,
      }).from(coachInteractions).where(gte(coachInteractions.createdAt, start30));

      const totalInputTokens = cacheStats.cacheReads + cacheStats.cacheWrites + cacheStats.plainInput;
      const cacheHitRate = totalInputTokens > 0 ? cacheStats.cacheReads / totalInputTokens : 0;

      // Monthly run rate from last 30 days actual
      const monthlyRunRate = last30.total;

      res.json({
        today:          { cost: today.total,   turns: today.turns },
        last7Days:      { cost: last7.total,   turns: last7.turns },
        last30Days:     { cost: last30.total,  turns: last30.turns },
        monthlyRunRate,
        cacheHitRate,
      });
    } catch (err: any) {
      console.error('[admin] summary failed:', err);
      res.status(500).json({ message: err.message });
    }
  });

  // ── Daily cost trend (last 30 days) ─────────────────────────────────────
  app.get('/api/admin/coach/trend', requireAdmin, async (_req, res) => {
    try {
      const start30 = new Date(Date.now() - 30 * 24 * 3600 * 1000);

      const rows = await db.select({
        day:    sql<string>`DATE(${coachInteractions.createdAt})::text`,
        cost:   sql<number>`COALESCE(SUM(${coachInteractions.costUsd}), 0)::float`,
        turns:  sql<number>`COUNT(*)::int`,
      })
      .from(coachInteractions)
      .where(gte(coachInteractions.createdAt, start30))
      .groupBy(sql`DATE(${coachInteractions.createdAt})`)
      .orderBy(sql`DATE(${coachInteractions.createdAt})`);

      res.json({ days: rows });
    } catch (err: any) {
      console.error('[admin] trend failed:', err);
      res.status(500).json({ message: err.message });
    }
  });

  // ── Question-bucket breakdown ───────────────────────────────────────────
  app.get('/api/admin/coach/buckets', requireAdmin, async (_req, res) => {
    try {
      const start30 = new Date(Date.now() - 30 * 24 * 3600 * 1000);

      const rows = await db.select({
        bucket: coachInteractions.questionBucket,
        count:  sql<number>`COUNT(*)::int`,
        cost:   sql<number>`COALESCE(SUM(${coachInteractions.costUsd}), 0)::float`,
      })
      .from(coachInteractions)
      .where(gte(coachInteractions.createdAt, start30))
      .groupBy(coachInteractions.questionBucket)
      .orderBy(desc(sql`COUNT(*)`));

      res.json({ buckets: rows });
    } catch (err: any) {
      console.error('[admin] buckets failed:', err);
      res.status(500).json({ message: err.message });
    }
  });

  // ── Page-context breakdown ──────────────────────────────────────────────
  app.get('/api/admin/coach/pages', requireAdmin, async (_req, res) => {
    try {
      const start30 = new Date(Date.now() - 30 * 24 * 3600 * 1000);

      const rows = await db.select({
        page:  coachInteractions.pageContext,
        count: sql<number>`COUNT(*)::int`,
        cost:  sql<number>`COALESCE(SUM(${coachInteractions.costUsd}), 0)::float`,
      })
      .from(coachInteractions)
      .where(gte(coachInteractions.createdAt, start30))
      .groupBy(coachInteractions.pageContext)
      .orderBy(desc(sql`COUNT(*)`));

      res.json({ pages: rows });
    } catch (err: any) {
      console.error('[admin] pages failed:', err);
      res.status(500).json({ message: err.message });
    }
  });

  // ── Most expensive turns this week ──────────────────────────────────────
  app.get('/api/admin/coach/expensive', requireAdmin, async (req, res) => {
    try {
      const limit = Math.min(parseInt((req.query.limit as string) ?? '20', 10), 100);
      const start7 = new Date(Date.now() - 7 * 24 * 3600 * 1000);

      const rows = await db.select()
        .from(coachInteractions)
        .where(gte(coachInteractions.createdAt, start7))
        .orderBy(desc(coachInteractions.costUsd))
        .limit(limit);

      res.json({ turns: rows });
    } catch (err: any) {
      console.error('[admin] expensive failed:', err);
      res.status(500).json({ message: err.message });
    }
  });

  // ── User cost table ─────────────────────────────────────────────────────
  app.get('/api/admin/coach/users', requireAdmin, async (_req, res) => {
    try {
      const start30 = new Date(Date.now() - 30 * 24 * 3600 * 1000);

      const rows = await db.select({
        userId:    coachInteractions.userId,
        turns:     sql<number>`COUNT(*)::int`,
        cost:      sql<number>`COALESCE(SUM(${coachInteractions.costUsd}), 0)::float`,
        lastTurn:  sql<Date>`MAX(${coachInteractions.createdAt})`,
      })
      .from(coachInteractions)
      .where(gte(coachInteractions.createdAt, start30))
      .groupBy(coachInteractions.userId)
      .orderBy(desc(sql`SUM(${coachInteractions.costUsd})`));

      res.json({ users: rows });
    } catch (err: any) {
      console.error('[admin] users failed:', err);
      res.status(500).json({ message: err.message });
    }
  });
}
*/

// ─────────────────────────────────────────────────────────────────────
// NOTE: The block above is wrapped in a comment because the recommended
// integration is to PASTE these route bodies directly into the existing
// `registerRoutes()` function in server/routes.ts, alongside the other
// Yahoo routes. That keeps the import surface and broadcast wiring
// consistent with the rest of the file.
//
// If you'd rather call it as a separate function, uncomment the block
// and add this line in registerRoutes() after the existing Yahoo
// endpoints:
//
//   registerYahooPhase2Routes(app, broadcast);
// ─────────────────────────────────────────────────────────────────────
export {};

// ─────────────────────────────────────────────────────────────────────
// shared/schema-additions.ts
//
// COMBINED v1.0 + v1.1 + v1.1a additions.
//
// APPEND THIS BLOCK to the bottom of shared/schema.ts (it just needs to
// be a top-level block in the file).
//
// Then run:  npm run db:push
//
// Three tables are added here:
//   1. yahoo_cache         — TTL-aware Yahoo API cache (v1.0)
//   2. coach_interactions  — Per-turn telemetry for the admin dashboard (v1.1a)
//
// Plus a note about adding `is_admin` to your users table — see the
// admin-auth section at the bottom of this file. For v1.1a we use an
// env-var fallback (ADMIN_USER_IDS) so this works even before you have
// a proper users table.
// ─────────────────────────────────────────────────────────────────────
import {
  pgTable, text, serial, integer, real, boolean, timestamp,
  jsonb, index,
} from "drizzle-orm/pg-core";

/**
 * yahoo_cache
 * ───────────
 * TTL-aware cache for Yahoo Fantasy API responses. The auto-sync
 * infrastructure reads/writes here so pages can call /api/yahoo/*
 * endpoints freely without hammering Yahoo (or the user).
 *
 * cacheKey scheme (single-user for now; userId is implicit = 1):
 *   "rosters"          — all 12 teams' rosters
 *   "standings"        — current standings
 *   "scoreboard"       — current week's matchups
 *   "settings"         — league scoring categories + roster positions
 *   "waivers:B"        — top batter waiver wire
 *   "waivers:P"        — top pitcher waiver wire
 *   "my-roster"        — user's roster (also used by /api/yahoo/sync-roster)
 *   "transactions"     — recent league transactions
 *
 * `data` is a Postgres JSONB column so we store the cleaned/parsed
 * shape — never the raw Yahoo XML-shaped JSON garbage.
 */
export const yahooCache = pgTable("yahoo_cache", {
  id:        serial("id").primaryKey(),
  cacheKey:  text("cache_key").notNull().unique(),
  data:      jsonb("data").notNull(),
  fetchedAt: timestamp("fetched_at").defaultNow().notNull(),
});

export type YahooCacheRow = typeof yahooCache.$inferSelect;

/**
 * coach_interactions
 * ──────────────────
 * One row per Coach turn (one user message + one assistant response).
 * This is the data layer for the admin dashboard (v1.1b).
 *
 * Records:
 *   - Full prompt + response text (option (d) — 90-day retention auto-deletes)
 *   - Cost breakdown (input/output/cache_creation/cache_read tokens + $)
 *   - Performance (response time, errors)
 *   - Categorization (page context, regex-bucketed question type)
 *   - Conversation linkage (so we can analyse multi-turn sessions)
 *
 * Retention: server/coach/retention.ts auto-deletes rows older than 90
 * days on a 6-hour interval. Adjust RETENTION_DAYS in that file if
 * needed.
 *
 * Privacy: when Phase 2 multi-user lands, surface in user settings:
 *   - "Delete my Coach history" button → deletes user's rows here
 *   - "Opt out of analytics" toggle → flag here, skip recording for them
 */
export const coachInteractions = pgTable("coach_interactions", {
  id:                  serial("id").primaryKey(),
  userId:              integer("user_id").notNull(),
  conversationId:      text("conversation_id").notNull(),
  turnNumber:          integer("turn_number").notNull(),

  // Content (90-day retention)
  userMessage:         text("user_message").notNull(),
  assistantMessage:    text("assistant_message").notNull(),

  // Context
  pageContext:         text("page_context"),
  questionBucket:      text("question_bucket"),

  // Cost breakdown
  model:               text("model").notNull(),
  inputTokens:         integer("input_tokens").notNull().default(0),
  outputTokens:        integer("output_tokens").notNull().default(0),
  cacheCreationTokens: integer("cache_creation_tokens").notNull().default(0),
  cacheReadTokens:     integer("cache_read_tokens").notNull().default(0),
  costUsd:             real("cost_usd").notNull().default(0),

  // Performance
  responseTimeMs:      integer("response_time_ms"),
  errored:             boolean("errored").notNull().default(false),
  errorMessage:        text("error_message"),

  createdAt:           timestamp("created_at").defaultNow().notNull(),
}, (t) => ({
  userIdIdx:        index("coach_interactions_user_id_idx").on(t.userId),
  createdAtIdx:     index("coach_interactions_created_at_idx").on(t.createdAt),
  conversationIdx:  index("coach_interactions_conversation_idx").on(t.conversationId, t.turnNumber),
  bucketIdx:        index("coach_interactions_bucket_idx").on(t.questionBucket),
}));

export type CoachInteractionRow = typeof coachInteractions.$inferSelect;
export type CoachInteractionInsert = typeof coachInteractions.$inferInsert;

/* ─────────────────────────────────────────────────────────────────────
 * ADMIN GATING — IS_ADMIN COLUMN
 * ─────────────────────────────────────────────────────────────────────
 *
 * For v1.1a, admin gating is handled via env var ADMIN_USER_IDS in
 * server/middleware/admin-auth.ts. This works today regardless of how
 * users are tracked.
 *
 * When you build out a proper users table (Phase 2 multi-user auth),
 * add a boolean column to it:
 *
 *     // In your users table definition:
 *     isAdmin: boolean("is_admin").notNull().default(false),
 *
 * Then update server/middleware/admin-auth.ts to check it (the file
 * has a TODO comment showing exactly where the swap goes).
 *
 * The env var fallback can stay in place forever as a backstop — if
 * the DB check fails or the user lookup is unavailable, the middleware
 * falls back to ADMIN_USER_IDS. That gives you a recovery path if
 * something ever borks user records.
 * ───────────────────────────────────────────────────────────────────── */

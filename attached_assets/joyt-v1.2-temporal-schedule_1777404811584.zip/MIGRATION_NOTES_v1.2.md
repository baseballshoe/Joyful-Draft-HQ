# JOYT v1.2 — Temporal Awareness + MLB Schedule Layer

This is a **drop-in patch** on top of the deployed v1.0 + v1.1 + v1.1a foundation. No schema changes. No new secrets needed.

## What this adds

- **Temporal awareness:** Coach now knows what day it is and where in the matchup week we are. No more "you're losing in 5 categories!" doom-spirals on day 1.
- **MLB schedule layer:** Per-team game counts injected into roster annotations. "Aaron Judge | 6 GP this week" — Coach reasons about schedule volume.
- **Two-start pitcher detection:** Pitchers tagged with their actual start count for the week (when probable pitchers data is available). "Bibee | ⭐ 2 STARTS this week" — Coach surfaces streaming priorities.
- **External data abstraction layer (`server/external/`):** Locked-in pattern for commercial-readiness. Internal code imports the interface; the MLB Stats API implementation can be swapped to a licensed provider before commercial launch.

## Pre-flight checks

Before unzipping:

- [ ] v1.0 + v1.1 + v1.1a foundation is deployed (verify by hitting `/api/admin/coach/summary` — should return data, not 404)
- [ ] No new Replit secrets needed for v1.2
- [ ] (Optional) Verify outbound HTTPS to `statsapi.mlb.com` works from Replit (it does by default)

## File inventory

```
server/external/
  schedule.ts                  [NEW]      — interface + provider binding
  schedule-impl.ts             [NEW]      — MLB Stats API implementation

server/
  yahoo-cache.ts               [REPLACE]  — adds prefix-based TTL lookup
                                            for new mlb:* keys

server/coach/
  context.ts                   [REPLACE]  — temporal awareness, schedule
                                            integration, two-start detection
  personality.ts               [REPLACE]  — temporal awareness guidance,
                                            schedule-aware analysis rules
```

**Total: 5 files, ~900 lines.**

## Migration steps (DO IN ORDER)

### Step 1 — Drop in new files

Create the new external directory and add the two files:

- `server/external/schedule.ts` (NEW)
- `server/external/schedule-impl.ts` (NEW)

### Step 2 — Replace existing files

Drop these in directly (no merge needed — full file replacements):

- `server/yahoo-cache.ts` — adds `CACHE_TTL_PREFIXES` and `getTTL()` helper. Backward compatible — all existing keys still work the same.
- `server/coach/context.ts` — temporal awareness, schedule annotations, two-start detection. Function signature `buildCoachContext()` is unchanged; `ai.ts` calls it the same way.
- `server/coach/personality.ts` — adds Temporal Awareness and Schedule-Aware Analysis sections to Coach's system prompt.

### Step 3 — No routes changes needed

This patch doesn't touch `server/routes.ts`. The schedule layer is consumed internally by `context.ts`; no new endpoints get exposed.

### Step 4 — No schema changes needed

This patch reuses the existing `yahoo_cache` table for MLB schedule + probables data (cache keys prefixed `mlb:schedule:` and `mlb:probables:`). No `npm run db:push` required.

### Step 5 — Smoke tests

Run these in order. Stop and fix anything that fails before continuing.

```bash
# 1. Verify new directory exists in deployed code
ls server/external/
# Expect: schedule.ts and schedule-impl.ts

# 2. Hit Coach with a temporal question — should reference today's date
#    Open Coach in the browser, ask: "What day is it and where are we
#    in the matchup week?"
#    Expect: Coach states the actual current day (e.g. "Tuesday, Apr 28")
#            and identifies day X of 7 in the matchup week

# 3. Hit Coach with a matchup question — should NOT doom-spiral
#    Ask: "How am I doing in the matchup?"
#    On day 1-2 of week, expect: calibrated answer that emphasizes early
#    sample size, schedule advantages, not panic mode
#    On day 5+, expect: more substantive analysis with current performance

# 4. Verify MLB Stats API is being cached
psql $DATABASE_URL -c "SELECT cache_key, fetched_at FROM yahoo_cache WHERE cache_key LIKE 'mlb:%';"
# Expect: at least 2 rows, like:
#   mlb:schedule:2026-04-27:2026-05-03
#   mlb:probables:2026-04-27:2026-05-03
# (NOTE: this checks the dev DB. If empty, hit /api/yahoo/cache-status
#  on the deployed app — it surfaces production cache state.)

# 5. Hit Coach with a pitcher question — verify schedule annotations
#    Ask: "Should I stream a pitcher this week?"
#    Expect: Coach references game counts and any 2-start pitchers in
#    available pool. If your league has a streamable 2-start guy
#    available, Coach should flag him.

# 6. Verify roster annotations show in raw context (debugging only)
#    Add temporary logging in askAIStream to log ctx.volatileBlock,
#    OR check the next coach_interactions row's user_message context.
#    Expect: roster lines have "| 6 GP this week" or similar appended.
```

If smoke test 4 returns zero rows, the schedule layer isn't fetching. Check Replit logs for errors mentioning `[coach/context]` or `MLB Stats API error`.

## What's running where (v1.2)

| Concern | File | Notes |
|---|---|---|
| Schedule provider interface | `server/external/schedule.ts` | Internal code imports from here only |
| MLB Stats API implementation | `server/external/schedule-impl.ts` | Pre-commercial swap target |
| Cache TTL prefix support | `server/yahoo-cache.ts` (`CACHE_TTL_PREFIXES`) | New |
| Temporal computation | `server/coach/context.ts` (`computeTemporalContext`) | New |
| Schedule annotations on player lines | `server/coach/context.ts` (`buildScheduleAnnotation`) | New |
| Coach temporal awareness rules | `server/coach/personality.ts` (`# TEMPORAL AWARENESS`) | New |
| Coach schedule-aware analysis rules | `server/coach/personality.ts` (`# SCHEDULE-AWARE ANALYSIS`) | New |

## Tuning knobs

- **Schedule cache TTL** — `server/yahoo-cache.ts` `CACHE_TTL_PREFIXES`. Schedules: 24h. Probables: 1h. Tighten probables if late-scratch pitcher changes start affecting Coach's recommendations.
- **Matchup week computation** — `server/coach/context.ts` `computeTemporalContext`. Hard-coded to Mon-Sun (most leagues). If your league uses different week boundaries, override here.
- **Two-start tag threshold** — `server/coach/context.ts` `buildScheduleAnnotation`. Currently flags any pitcher with ≥2 probable starts. Solid as-is.

## Rollback

If anything in v1.2 breaks production:

1. **Quick disable schedule layer:** In `server/coach/context.ts`, comment out the `safeGetWeekSchedule` and `safeGetProbables` calls. Coach falls back to v1.1 behavior (no temporal/schedule awareness). Restart.
2. **Full rollback:** Revert the 3 modified files and delete `server/external/`. Schema additions (none) require no rollback.

## Pre-commercial swap reminder (Phase 3 launch checklist)

`server/external/schedule-impl.ts` uses MLB Stats API which is non-commercial-only per their TOS. **Before charging users:**

1. Choose a licensed provider:
   - **SportsDataIO** ($500-1500/mo) — sweet spot for indie commercial, no Statcast advanced metrics
   - **Sportradar** ($1,500-5,000/mo) — full Statcast tier, official MLB partner

2. Rewrite `server/external/schedule-impl.ts` against the chosen provider's API.

3. Verify `getWeekSchedule()` and `getProbableStarts()` interfaces still match. The rest of the app keeps working.

4. Update the import line in `server/external/schedule.ts` to point at the new impl.

5. Update compliance docs to reflect the licensed source.

That's the entire commercial swap for the schedule layer. Same pattern applies to future external sources (`news.ts`, `injuries.ts`, etc.).

## What's deferred

Still on the roadmap, not in this pack:

- **v1.1b Admin dashboard UI** — telemetry layer collecting data; UI ships once enough data exists to design against
- **6 new pages** — Season Dashboard, Matchup, Waivers, Standings, Transactions, News. Hooks already shipped in v1.0 (`use-yahoo-data.ts`)
- **News integration** — `server/external/news.ts` will use the same abstraction pattern when the News page is built

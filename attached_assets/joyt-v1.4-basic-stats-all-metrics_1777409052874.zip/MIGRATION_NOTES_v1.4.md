# JOYT v1.4 — Basic Stats Backfill + All-Metrics Formatter + Limited-Data Personality

## What this fixes

**1. Recently-debuted players had near-empty stats.** Parker Messick
example: only `xwoba_against` and `barrel_pct_against` populated; ERA,
WHIP, IP, GS, K, BB, QS all NULL. Reason: pybaseball's Savant scraping
covers different endpoints inconsistently for new debuts. Solution:
pull basic stats directly from MLB Stats API (the source of truth)
and merge with Savant + FanGraphs in Coach's context.

**2. Coach was missing half the schema columns.** Audit revealed:
- Pitcher field-name bug: `stats.strikeouts` vs schema `strikeoutsPitched`
  → every pitcher's K column silently NULL in Coach's view
- Same bug for `hitsAllowed`, `walksAllowed`, `earnedRuns`, `homerunsAllowed`
- Missing entirely from formatter: `xFIP`, `WAR`, `kRate`, `bbRate`,
  `kMinusBB`, `barrelPctAgainst`, `hardHitPctAgainst`, `xwOBAagainst`,
  `xBAagainst`, `chasePctInduced`, `zonePct`
- Batter side missing: `wOBA`, `wRC+`, `OPS`, `BABIP`, `xSLG`, plate
  discipline (`whiffPct`, `chasePct`, `contactPct`, `zoneContactPct`),
  exit velo, launch angle, all counting stats

**3. Coach refused to engage with limited-data players.** When a
player had sparse stats, Coach would either give zero analysis or
hedge so heavily it was useless. Personality v4 adds a
"limited-data flagging" rule: subtly note the limit in one phrase,
then still give a confident read with appropriate calibration.

## What this adds

- `scripts/pull_basic_stats.py` — MLB Stats API basic stats backfill
- `.github/workflows/pull-basic-stats.yml` — nightly cron at 06:15 UTC
- Multi-source row merging in `server/coach/context.ts` (MLB API +
  FanGraphs + Savant columns combined per player)
- Comprehensive batter and pitcher formatters — every useful column
- Field-name bug fixes in the pitcher formatter
- Quality Starts (`QS`) explicitly captured and surfaced
- `# WHEN DATA IS LIMITED — NOTE IT, BUT STILL HELP` section in
  personality.ts

## Pre-flight checks

- [ ] v1.0 + v1.1 + v1.1a + v1.2 + v1.3 are all deployed
- [ ] v1.3's `pull-players` workflow has run at least once successfully
  (verify: `mlbam_id` populated for active players in `player_ids`)
- [ ] No new Replit secrets needed
- [ ] GitHub repo secret `DATABASE_URL` already set

## File inventory

```
.github/workflows/
  pull-basic-stats.yml       [NEW]      — nightly 06:15 UTC cron

scripts/
  pull_basic_stats.py        [NEW]      — MLB Stats API → batter_stats
                                            + pitcher_stats with
                                            data_source='mlb-stats-api'

server/coach/
  context.ts                 [REPLACE]  — multi-source merge,
                                            comprehensive formatters,
                                            field-name bug fixes
  personality.ts             [REPLACE]  — adds limited-data rule
```

**Total: 4 files, ~1,400 lines.**

## Migration steps

### Step 1 — Drop in new files
- `scripts/pull_basic_stats.py`
- `.github/workflows/pull-basic-stats.yml`

### Step 2 — Replace existing files
- `server/coach/context.ts`
- `server/coach/personality.ts`

### Step 3 — No schema changes, no routes changes
This release writes to existing tables only. No `npm run db:push` needed.

### Step 4 — Trigger pull-basic-stats manually
1. GitHub → Actions → "Pull basic stats" → Run workflow → main
2. Watch the logs. Should complete in under 30 seconds. Expected output:
   ```
   Fetching pitching stats for 2026...
     Got ~700 pitching splits
   Fetching hitting stats for 2026...
     Got ~900 hitting splits
     Pitchers: matched ~700, unmatched ~5
     Batters: matched ~900, unmatched ~5
     Writing ~700 pitcher rows...
     Writing ~900 batter rows...
   Done in ~15s
   ```

The "unmatched" numbers should be small — those are players in MLB Stats
API but missing from `player_ids`. If unmatched is high (>50), run
`pull-players.yml` first to refresh the roster seed.

### Step 5 — Smoke tests

```bash
PGURL='postgresql://neondb_owner:npg_t8Ihb0ixUgGd@ep-billowing-haze-akye78bh.c-3.us-west-2.aws.neon.tech/neondb?sslmode=require'

# 1. Verify Messick now has basic stats
psql "$PGURL" -c "
  SELECT data_source, games_started, innings_pitched, era, whip, quality_starts,
         strikeouts_pitched, walks_allowed
  FROM pitcher_stats
  WHERE player_id = 284 AND season = 2026
  ORDER BY data_source;
"
# Expect: 2 rows
#   mlb-stats-api: GS=5, IP=30.2, ERA=1.76, WHIP=0.88, QS=2, K=29, BB=8
#   savant:        most NULL but xwoba_against populated
# Coach merges these into one view.

# 2. Spot-check a position player Coach was missing data on
psql "$PGURL" -c "
  SELECT data_source, games, plate_apps, avg, obp, slg, ops, home_runs, rbi, stolen_bases
  FROM batter_stats
  WHERE player_id = (SELECT id FROM players WHERE name = 'Juan Soto')
    AND season = 2026
  ORDER BY data_source;
"

# 3. Verify QS is populated for known QS-leaders
psql "$PGURL" -c "
  SELECT p.name, ps.quality_starts, ps.games_started, ps.era
  FROM pitcher_stats ps
  JOIN players p ON p.id = ps.player_id
  WHERE ps.season = 2026
    AND ps.data_source = 'mlb-stats-api'
    AND ps.quality_starts >= 3
  ORDER BY ps.quality_starts DESC LIMIT 10;
"
```

### Step 6 — Coach tone test

Ask Coach the original frustrating questions again:
1. "What about Parker Messick?"
   - Expect: actual ERA/WHIP/QS/IP cited, brief "limited data" caveat
     woven in (one phrase), then a confident read
2. "How am I doing this week?"
   - Expect: warmer tone, no lecture, no doom-spiral on day 1-2
3. "How does my team compare to the rest of the league?"
   - Expect: prose without bold mini-headers, situational awareness
     (factor in 12-team thin wire), pair-diagnosis-with-direction
     (specific recs OR honest "wire's worse")

If any of those still feel off, paste the response and we tune
personality further.

## Cost impact

The volatile block grows because each player line is now ~5-7 lines
(was ~1 line) with all metrics. Rough estimate per turn:
- Before v1.4: ~8K input tokens, ~$0.036/turn
- After v1.4:  ~12K input tokens, ~$0.045-0.050/turn

Worth it. Coach now has ~2.5x the data per player and gives
proportionally better analysis.

Static prefix and semi-static blocks still cache, so multi-turn
sessions cost less than this implies.

## Rollback

If anything breaks:
1. Revert `context.ts` only → keep v1.4 data flowing, but Coach reads
   only the priority-source row (still better than v1.3 because of
   pull_basic_stats writing data)
2. Revert `personality.ts` only → keeps the data improvements but
   restores v1.3 personality
3. Disable `pull-basic-stats.yml` workflow → no new MLB API rows
   written, existing rows stay until next pull-stats DELETEs them

## Pre-commercial swap reminder

`scripts/pull_basic_stats.py` uses MLB Stats API which is non-commercial.
**Pre-Phase-3 launch:** rewrite to use SportsDataIO ($500-1500/mo) or
Sportradar ($1,500-5,000/mo). The DB writes don't change — same
schema, just different source.

## What's still deferred

- Admin dashboard UI (waiting on more telemetry data)
- Question-intent detection in `categorizer.ts` (still skipping —
  personality file alone handles intent)
- 6 new pages (Season Dashboard, Matchup, Waivers, Standings,
  Transactions, News)
- Phase 3 commercial prep (multi-user auth, Stripe, licensed
  external data swaps, ToS/Privacy)

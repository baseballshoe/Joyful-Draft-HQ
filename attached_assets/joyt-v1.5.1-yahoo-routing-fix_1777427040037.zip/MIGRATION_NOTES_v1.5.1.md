# JOYT v1.5.1 — Yahoo Position Routing + Stats Parsing Fix

## What this fixes

v1.5 wrote 1,456 batter rows and 0 pitcher rows. Of those 1,456:
- All 5 known SPs (Skubal, Strider, Skenes, Crochet, Messick) got
  written to `batter_stats`
- Only 454 of 1,456 had any actual batter stats populated (HR, SB)
- All other columns (games, at_bats, runs, RBI, etc.) were NULL

Root cause: my v1.5 code in `yahoo-stats.ts` read Yahoo's response
using fixed array indices (`info[4]?.display_position`,
`info[6]?.editorial_team_abbr`, etc.). That works for the roster
endpoint but NOT the league-players endpoint — Yahoo orders fields
differently between endpoints.

The fix: use the same `findAttr()` walker pattern that the existing
`yahoo.ts` uses for its other endpoints. It iterates the array
looking for the matching key — robust to Yahoo reshuffling field
order.

Bonus improvement: switched position detection from parsing
`display_position` strings to reading `position_type` directly.
Yahoo's canonical classifier is "P" or "B" — no string parsing
needed, no edge cases for multi-position players ("1B,3B" etc.).

## File inventory

```
server/external/
  yahoo-stats.ts               [REPLACE]  — findAttr-based parsing,
                                              position_type routing,
                                              classification diagnostics

scripts/
  pull_yahoo_stats.ts          [REPLACE]  — logs new diagnostic
                                              counters
```

**Total: 2 file replacements. No new files. No workflow file changes,
so no GitHub OAuth scope wall this time.**

## Migration steps

### Step 1 — Replace files

Drop these from the v1.5.1 zip into your repo:
- `server/external/yahoo-stats.ts` (replaces v1.5)
- `scripts/pull_yahoo_stats.ts` (replaces v1.5)

### Step 2 — Push

```bash
git add server/external/yahoo-stats.ts scripts/pull_yahoo_stats.ts
git commit -m "v1.5.1: fix Yahoo position routing + stats parsing (findAttr walker, position_type classifier)"
git push origin main
```

Should push cleanly — no workflow file changes.

### Step 3 — Re-trigger Pull Yahoo stats

GitHub → Actions → Pull Yahoo stats → Run workflow → main

Expected log:
```
[INFO] Starting Yahoo stats pull
[INFO] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[INFO] Yahoo stats pull complete
[INFO]   Total players seen:          ~2,400
[INFO]   Classified as pitcher:       ~900-1,100
[INFO]   Classified as batter:        ~1,300-1,500
[INFO]   Classified UNKNOWN:          0  (or very small)
[INFO]   Matched to our DB:           ~1,400-1,500
[INFO]   Unmatched (skipped):         ~900  (these are prospects — fixed in v1.5.2)
[INFO]   Pitcher rows written:        ~500
[INFO]   Batter rows written:         ~900
[INFO]   QS total across league:      ~140-200
[INFO]   Elapsed:                     ~30s
[INFO] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

The split between pitchers and batters should look right now (roughly
40/60 pitcher/batter is normal for MLB). And QS total should be a real
number, not 0.

### Step 4 — Verify Messick now has Yahoo data with QS

```bash
PGURL='postgresql://neondb_owner:npg_t8Ihb0ixUgGd@ep-billowing-haze-akye78bh.c-3.us-west-2.aws.neon.tech/neondb?sslmode=require'

psql "$PGURL" -c "
  SELECT data_source, games_started, innings_pitched, era, whip,
         quality_starts, strikeouts_pitched, walks_allowed
  FROM pitcher_stats
  WHERE player_id = 284 AND season = 2026
  ORDER BY data_source;
"
```

Expected:
- `yahoo`: GS=6, ERA=1.73, WHIP=0.88, **QS populated**, K=38
- `mlb-stats-api`: GS=6, ERA=1.73, WHIP=0.88, K=38 (existing)
- `savant`: mostly NULL but xwOBA against, barrel% (existing)
- `fangraphs` (if v1.5 FG name-fallback caught him): FIP, xFIP, WAR

### Step 5 — Verify QS leaderboard

```bash
psql "$PGURL" -c "
  SELECT p.name, ps.quality_starts, ps.games_started, ps.era
  FROM pitcher_stats ps
  JOIN players p ON p.id = ps.player_id
  WHERE ps.season = 2026 AND ps.data_source = 'yahoo'
    AND ps.quality_starts >= 1
  ORDER BY ps.quality_starts DESC, ps.era ASC
  LIMIT 15;
"
```

Compare against your Yahoo league page's QS leaderboard. Should match
exactly (or within 1 if a game finished between the nightly run and
when you check).

### Step 6 — Coach test

Ask Coach: "what about parker messick?"

Expected:
- Cites real numbers including QS (Yahoo value, authoritative)
- Brief "limited data" caveat woven in
- Confident recommendation
- No bold mini-headers, prose response

## What's still deferred to v1.5.2

The 942 unmatched players are mostly prospects — minor leaguers Yahoo
makes available in your league but who aren't in our `players` table
because `pull_players.py` only ingests MLB-rostered players.

v1.5.2 will:
- Insert Yahoo-only players into the players table during the Yahoo run
- Auto-link MLBAM IDs when prospects get called up
- Add Coach personality module: "Prospects as first-class citizens"
- Update context layer to recognize and label prospects

Estimated v1.5.2 scope: ~200 lines across 4 files.

**Important: this is required to fully deliver the prospect-stash
feature Josh wants. v1.5.1 fixes the existing data; v1.5.2 expands
coverage to prospects.**

## Rollback

If v1.5.1 misbehaves:
```bash
git revert HEAD
git push origin main
```

This restores the v1.5 code (which "works" but produces wrong data).
Disable the Pull Yahoo stats workflow if needed:
GitHub → Actions → Pull Yahoo stats → ··· → Disable workflow

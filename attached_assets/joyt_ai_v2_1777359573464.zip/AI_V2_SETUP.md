# JOYT AI v2 — The Honest Guru Update

This update fixes the hallucination problem and adds:
- Full advanced stats sent to AI (was only sending a few)
- Available player pool with stats (so AI can recommend from real data)
- MLB Stats API for injuries/status (no more recommending IL'd guys)
- Conversational guru tone (no more corporate report headers)
- Intent detection (streamer vs sustainable vs breakout)
- Strict honesty rules (no hallucinating stats)
- Fixed "Ask 🤖" button order
- Dashboard search bar variant

## Files in this zip

1. `joyt_player_status_schema.ts` — New player_status table
2. `pull_stats.py` — Updated stats puller (now also fetches MLB Stats API)
3. `joyt_ai_service_v2.ts` — Rewritten AI service (replace existing server/ai.ts)
4. `joyt_ai_component_v2.tsx` — Updated component (replace existing ask-ai.tsx)
5. `AI_V2_SETUP.md` — This guide

## Setup steps

### 1. Add the player_status schema
Paste contents of `joyt_player_status_schema.ts` at the bottom of `shared/schema.ts`

### 2. Run db:push
```bash
npm run db:push
```

### 3. Replace the Python stats puller
Replace `scripts/pull_stats.py` with the contents of `pull_stats.py`

### 4. Replace the AI service
Replace `server/ai.ts` with the contents of `joyt_ai_service_v2.ts`

### 5. Replace the component
Replace `client/src/components/ask-ai.tsx` with the contents of `joyt_ai_component_v2.tsx`

### 6. Update the dashboard to show the search bar
In `client/src/pages/dashboard.tsx`, find your existing AskAI usage:
```tsx
<AskAI pageContext="dashboard" />
```

Change it to:
```tsx
<AskAI pageContext="dashboard" showSearchBar />
```

Place it near the top of your dashboard JSX (right after the stat strip is a good spot).

### 7. Commit and push, then run GitHub Actions
The new MLB Stats API code is in the Python script. Commit + push, then trigger the workflow manually.

You should see new output:
```
=== MLB Stats API: Player Status ===
  Fetched 30 MLB teams
  Collected status for ~1300 of our players
  Writing 1300 rows
  Injury breakdown: {'IL10': 25, 'IL15': 12, 'IL60': 18, 'DTD': 8}
```

## What's different now

### Before:
- AI was sending ~6 stats per player
- Only sent roster — no available players
- No injury data
- Generic recommendations (often hallucinated)
- Corporate report-style responses

### After:
- AI sends ALL ~30 stats per player
- Sends top 60 available players with full stats
- Injury status filtered (no IL60 recommendations)
- Player status / current team awareness
- Conversational guru tone
- Strict no-hallucination rules in system prompt
- Intent detection (asks if intent is unclear)

## Test it

After deploying, ask the same question that gave bad results:
"Give me your top 3 choices for each of the 3 problems you listed"

You should now see:
- Real recommendations from the actual available pool
- No injured players recommended
- Stats cited matching what's in your DB
- More conversational, less corporate
- Either explicit intent (sustainable vs streamer) or clarification

## What's still missing (future sessions)

- Rolling 7/14/30 day stats (for breakout detection)
- Historical baselines for context
- Real-time lineup data
- News integration

These are the next logical additions.

// ── ADD THIS TO THE BOTTOM OF shared/schema.ts ──────────────────────────
//
// Player status / injury / metadata from MLB Stats API.
// Populated by the nightly GitHub Actions job (alongside FanGraphs/Savant).
//
// After pasting, run: npm run db:push

import { pgTable, text, integer, real, timestamp, serial, boolean } from "drizzle-orm/pg-core";

// ── Player status: injuries, role, current team info ──────────────────────
// One row per active MLB player. Updated nightly from MLB Stats API.
export const playerStatus = pgTable("player_status", {
  id:             serial("id").primaryKey(),
  playerId:       integer("player_id").notNull().unique(),  // FK to players.id
  mlbamId:        integer("mlbam_id"),

  // Active / injury status
  isActive:       boolean("is_active").default(true),
  injuryStatus:   text("injury_status"),       // 'IL10' | 'IL15' | 'IL60' | 'DTD' | 'OUT' | null (healthy)
  injuryNotes:    text("injury_notes"),         // 'Right hamstring strain' | etc
  injuryReturnDate: text("injury_return_date"), // Estimated return ('2026-05-15') if known

  // Current MLB context
  currentTeam:    text("current_team"),         // Three-letter code: 'BAL'
  currentLeague:  text("current_league"),       // 'AL' | 'NL'
  currentPosition: text("current_position"),    // Their primary defensive position
  jerseyNumber:   text("jersey_number"),
  battingHand:    text("batting_hand"),         // 'L' | 'R' | 'S'
  throwingHand:   text("throwing_hand"),

  // Role / playing time signal
  rosterStatus:   text("roster_status"),        // 'active' | '40-man' | 'minors' | 'free-agent'
  positionType:   text("position_type"),        // 'Pitcher' | 'Hitter' | 'Catcher' | 'Two-Way'

  // Bio
  birthDate:      text("birth_date"),
  age:            integer("age"),
  heightInches:   integer("height_inches"),
  weightLbs:      integer("weight_lbs"),

  // Metadata
  dataSource:     text("data_source").default('mlb-stats-api'),
  fetchedAt:      timestamp("fetched_at").defaultNow(),
});

export type PlayerStatus = typeof playerStatus.$inferSelect;

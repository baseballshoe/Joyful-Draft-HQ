# JOYT v1.5.1.5 — Markdown Rendering + Hard-No-Headers + League-Tie

## What this fixes

**1. Coach's `**bold**` was rendering as literal asterisks in the chat UI.**
   Root cause: client/src/components/ask-ai.tsx renders message content
   as raw text inside a div. Coach outputs markdown correctly, but the
   UI doesn't convert it to HTML.

   Fix: install react-markdown and wrap the message render in
   `<ReactMarkdown>`. Asterisks become bold/italic, asterisk-bullets
   render properly, the whole output goes from "looks broken" to
   "polished and modern."

**2. Coach used `## The Good News` headers despite the no-markdown
   rule.**
   Root cause: v1.5.1.4 personality said "no markdown headers" in one
   section but said "mini bold-headers OK for matchup walkthroughs" in
   another, and Coach interpreted the second as license to use any
   header style for walkthroughs — including `##`.

   Fix: hard universal rule. NO `##` EVER, no exceptions, with explicit
   examples of what the chat UI does to `##` (renders the literal
   text, makes Coach look broken). Bold mini-labels (`**Verdict:**`)
   are the ONLY way to add structure.

**3. Coach inconsistently tied recommendations to the user's league.**
   Root cause: v1.5.1.4 had a "pair diagnosis with direction" rule but
   it was about WHAT to recommend (swap names, paths forward), not
   WHY a player fits THIS user's specific league. Result: Coach
   recommended walks-heavy players in an AVG-not-OBP league.

   Fix: new explicit "TIE EVERY RECOMMENDATION TO THE USER'S SPECIFIC
   LEAGUE" section with concrete good/bad examples. Pattern is
   [player observation] + [why it matters HERE].

## File inventory

```
client/src/components/ask-ai.tsx     [PATCH]    — add ReactMarkdown
                                                   import + wrap message
                                                   render
package.json                          [PATCH]    — add react-markdown
                                                   dep (via npm install)
server/coach/personality.ts           [REPLACE]  — hard no-headers rule
                                                   + league-tie rule
```

**Total: 1 file replacement + 2 patches. No workflow files (no OAuth
scope wall to deal with).**

## The ask-ai.tsx patches (Replit AI handles these)

**Patch 1 — Add import near the top of the file:**

Find the line:
```
import { useState, useEffect, useRef } from 'react';
```

Add immediately after it:
```typescript
import ReactMarkdown from 'react-markdown';
```

**Patch 2 — Replace the message content render block:**

Find this block (around line 477):
```tsx
              }}>
                {m.content || (m.role === 'assistant' && isStreaming && i === messages.length - 1
                  ? <span style={{ opacity: .5 }}>thinking it over…</span>
                  : ''
                )}
              </div>
```

Replace with:
```tsx
              }}>
                {m.content
                  ? <ReactMarkdown
                      components={{
                        // Strip all heading levels — Coach should never output headers,
                        // but if one slips through render it as a bold paragraph instead
                        // of letting it explode into a giant heading.
                        h1: ({children}) => <strong style={{display:'block', marginTop:8}}>{children}</strong>,
                        h2: ({children}) => <strong style={{display:'block', marginTop:8}}>{children}</strong>,
                        h3: ({children}) => <strong style={{display:'block', marginTop:8}}>{children}</strong>,
                        // Compact paragraphs — no big margins between them
                        p:  ({children}) => <p style={{margin:'0 0 8px 0'}}>{children}</p>,
                        // Tight lists when they appear
                        ul: ({children}) => <ul style={{margin:'4px 0', paddingLeft:20}}>{children}</ul>,
                        ol: ({children}) => <ol style={{margin:'4px 0', paddingLeft:20}}>{children}</ol>,
                        li: ({children}) => <li style={{margin:'2px 0'}}>{children}</li>,
                      }}
                    >
                      {m.content}
                    </ReactMarkdown>
                  : (m.role === 'assistant' && isStreaming && i === messages.length - 1
                      ? <span style={{ opacity: .5 }}>thinking it over…</span>
                      : '')
                }
              </div>
```

ALSO: the parent div has `whiteSpace: 'pre-wrap'` which can interact
weirdly with the rendered markdown HTML. ReactMarkdown handles its own
whitespace. The `pre-wrap` is fine to leave for the streaming-text
fallback case.

## Migration steps

### Step 1 — Upload zip to Replit, give Replit AI this prompt:

```
v1.5.1.5 deploy. I uploaded joyt-v1.5.1.5-markdown-and-rules.zip to
project root. Three changes to apply:

1. Install react-markdown:
   npm install react-markdown

2. Replace this file from the zip:
   server/coach/personality.ts

3. Patch client/src/components/ask-ai.tsx with TWO edits:

   EDIT A — add ReactMarkdown import.
   Find this exact line:
     import { useState, useEffect, useRef } from 'react';
   Add this line immediately after it:
     import ReactMarkdown from 'react-markdown';

   EDIT B — replace the message render block.
   Find this exact block (it should appear once around line 477):
     ```
                   }}>
                     {m.content || (m.role === 'assistant' && isStreaming && i === messages.length - 1
                       ? <span style={{ opacity: .5 }}>thinking it over…</span>
                       : ''
                     )}
                   </div>
     ```
   Replace with:
     ```
                   }}>
                     {m.content
                       ? <ReactMarkdown
                           components={{
                             h1: ({children}) => <strong style={{display:'block', marginTop:8}}>{children}</strong>,
                             h2: ({children}) => <strong style={{display:'block', marginTop:8}}>{children}</strong>,
                             h3: ({children}) => <strong style={{display:'block', marginTop:8}}>{children}</strong>,
                             p:  ({children}) => <p style={{margin:'0 0 8px 0'}}>{children}</p>,
                             ul: ({children}) => <ul style={{margin:'4px 0', paddingLeft:20}}>{children}</ul>,
                             ol: ({children}) => <ol style={{margin:'4px 0', paddingLeft:20}}>{children}</ol>,
                             li: ({children}) => <li style={{margin:'2px 0'}}>{children}</li>,
                           }}
                         >
                           {m.content}
                         </ReactMarkdown>
                       : (m.role === 'assistant' && isStreaming && i === messages.length - 1
                           ? <span style={{ opacity: .5 }}>thinking it over…</span>
                           : '')
                     }
                   </div>
     ```

4. Verify changes:
   - npm ls react-markdown (should show installed version)
   - grep -c "ReactMarkdown" client/src/components/ask-ai.tsx (expect 3+)
   - grep -c "ABSOLUTE FORMATTING RULE" server/coach/personality.ts (expect 1)
   - grep -c "TIE EVERY RECOMMENDATION" server/coach/personality.ts (expect 1)

5. Restart the app to pick up the new TypeScript files and dependencies.

6. Delete the zip from project root after extracting:
   - rm joyt-v1.5.1.5-markdown-and-rules.zip
   - rm MIGRATION_NOTES_v1.5.1.5.md (if extracted to root)

7. Tell me when verification passes. Don't commit to git yet — I'll
   handle git myself.

If any step fails, stop and tell me. Don't improvise. Especially with
the ask-ai.tsx patches: if the "find this exact block" doesn't match,
stop and show me what you actually find.
```

### Step 2 — After Replit AI confirms, push from shell

No workflow files in this version, so no OAuth scope wall:

```bash
cd ~/workspace
git status
# Should show: 1 modified .ts (personality), 1 modified .tsx (ask-ai),
#              1 modified .json (package.json), 1 new .json (package-lock.json)

git add server/coach/personality.ts client/src/components/ask-ai.tsx \
        package.json package-lock.json
git commit -m "v1.5.1.5: markdown rendering + hard no-headers + league-tie"
git push origin main
```

### Step 3 — Republish

Replit Deploy tab → Republish → wait for green.

### Step 4 — Smoke tests

**Test 1 — Markdown rendering (the big one):**
> what about messick?

Expected: `**bold**` text now renders as actual bold. `*italics*` render
as italics. The output should look polished and visually distinct.

**Test 2 — Hard no-headers rule:**
> walk me through my matchup

Expected: NO `##` anywhere. Mini bold-labels like "**Where you're
winning:**" or "**The play:**" but NEVER `## Some Section`.

**Test 3 — League-tie rule:**
> any waiver wire targets that fit my team?

Expected: Every recommendation tied to user's specific league:
"Walker — 7 games this week, your league counts R/HR/RBI heavy..."
or "Schanuel walks but your league is AVG not OBP — pass." NOT generic
"this guy is decent."

## What's still pinned for v1.5.2 and beyond

(unchanged from v1.5.1.4 migration notes)

- **v1.5.2** — Prospect ingestion + MLBAM auto-link + prospects-as-
  first-class personality + context labeling + sync players.status
  with Yahoo league rosters
- **v1.5.3** — FG QS column debug
- **v1.6** — DELETE+INSERT transaction wrapping
- **v1.7** — Dynamic context loading + tiered Coach plans
- **v1.8+** — Admin dashboard, 6 new pages, splits/batted-ball schema
- **Pre-Phase-3** — Yahoo commercial license, SportsDataIO swap,
  multi-user auth, Stripe, ToS/Privacy

## Rollback

If anything misbehaves:
```bash
git revert HEAD
git push origin main
```
Then Republish.

# JOYT v1.5 — Yahoo Stats Pipeline + FanGraphs Name-Fallback

## What this delivers

**Build A — Yahoo as authoritative stats source**

Pulls every category your league scores (AVG, HR, SB, RBI, R, QS,
SAVE, ERA, WHIP, K) directly from Yahoo for every rosterable player
in your league. Yahoo's numbers match your league page exactly,
which means Coach's category math always agrees with what you see
in Yahoo.

Solves the QS gap completely — Yahoo computes QS authoritatively,
no local computation needed. Fixes Messick AND every other player
where MLB Stats API / FanGraphs lags.

Scope: ~1,200-1,500 players (every player Yahoo lists for your
league as either rostered or available, including prospect-stash
candidates).

**Build B — FanGraphs name-fallback in pull_stats.py**

Same pattern v1.3 used to fix MLBAM ID lookup gaps — when
FanGraphs scrape returns a player whose `IDfg` isn't in our
`player_ids` table, fall back to name match against `players`. This
captures FanGraphs sabermetrics (xFIP, FIP, SIERA, WAR, kRate,
bbRate, K-BB%, wOBA, wRC+) for new debuts that Chadwick Register
hasn't backfilled FG IDs for yet.

## File inventory

```
.github/workflows/
  pull-yahoo-stats.yml         [NEW]      — nightly cron, 06:45 UTC

scripts/
  pull_yahoo_stats.ts          [NEW]      — orchestrator (tsx-runnable)

server/external/
  yahoo-stats.ts               [NEW]      — Yahoo stats puller, parser,
                                              DB writer

server/
  yahoo.ts                     [PATCH]    — add `export` to yahooFetch
                                              (1 char change)

server/coach/
  context.ts                   [PATCH]    — SOURCE_PRIORITY adds 'yahoo'
                                              at front (1 line change)

scripts/
  pull_stats.py                [PATCH]    — FG name-fallback (~30 line
                                              addition to two functions)
```

**Total: 3 NEW files, 3 patches.**

## Pre-flight requirements

- v1.0 + v1.1 + v1.2 + v1.3 + v1.4 deployed and stable
- Yahoo OAuth currently connected (you can verify by visiting `/yahoo`
  on the running app — should show your league as connected)
- GitHub repo secrets set: `DATABASE_URL`, `YAHOO_CLIENT_ID`,
  `YAHOO_CLIENT_SECRET`, `APP_BASE_URL=https://drafthq.replit.app`

If `YAHOO_CLIENT_ID` / `YAHOO_CLIENT_SECRET` aren't yet set as GitHub
repo secrets (they're already in Replit Secrets, but workflow needs
them in GitHub):

1. Go to https://github.com/baseballshoe/Joyful-Draft-HQ/settings/secrets/actions
2. Click "New repository secret"
3. Add `YAHOO_CLIENT_ID` (paste the value from Replit Secrets)
4. Add `YAHOO_CLIENT_SECRET` (paste the value from Replit Secrets)
5. Add `APP_BASE_URL` with value `https://drafthq.replit.app`

## Migration steps

### Step 1 — Drop in NEW files

From the v1.5 zip, copy these into your repo:
- `.github/workflows/pull-yahoo-stats.yml`
- `scripts/pull_yahoo_stats.ts`
- `server/external/yahoo-stats.ts`

### Step 2 — Patch `server/yahoo.ts` (one-character change)

Find this line:
```typescript
async function yahooFetch(path: string): Promise<any> {
```

Add `export` so it becomes:
```typescript
export async function yahooFetch(path: string): Promise<any> {
```

That's the only change. yahoo-stats.ts imports `yahooFetch` so it
needs to be exported. No other code paths affected.

### Step 3 — Patch `server/coach/context.ts` (one line)

Find this line:
```typescript
const SOURCE_PRIORITY = ['mlb-stats-api', 'fangraphs', 'savant'];
```

Replace with:
```typescript
const SOURCE_PRIORITY = ['yahoo', 'mlb-stats-api', 'fangraphs', 'savant'];
```

This makes Yahoo the highest-priority source in the multi-source
merge. For any column Yahoo populates, Yahoo wins. For columns Yahoo
doesn't populate (advanced sabermetrics, Statcast), other sources fill
in via the existing v1.4 merge logic.

### Step 4 — Patch `scripts/pull_stats.py` (FG name-fallback)

Find the `pull_fangraphs_pitchers(conn)` function. Currently looks
roughly like:

```python
def pull_fangraphs_pitchers(conn):
    log.info('=== FanGraphs Pitchers ===')
    df = try_fangraphs_pitchers()
    if df is None:
        return 0
    with conn.cursor() as cur:
        cur.execute('SELECT fangraphs_id, player_id FROM player_ids WHERE fangraphs_id IS NOT NULL')
        fg_to_pid = dict(cur.fetchall())
    records = []
    for _, row in df.iterrows():
        fg_id = safe_int(row.get('IDfg'))
        pid = fg_to_pid.get(fg_id)
        if not pid: continue
        records.append((...))
```

Replace with this version (the name-fallback additions are marked):

```python
def pull_fangraphs_pitchers(conn):
    log.info('=== FanGraphs Pitchers ===')
    df = try_fangraphs_pitchers()
    if df is None:
        return 0
    with conn.cursor() as cur:
        cur.execute('SELECT fangraphs_id, player_id FROM player_ids WHERE fangraphs_id IS NOT NULL')
        fg_to_pid = dict(cur.fetchall())
        # ── v1.5: name-fallback for players Chadwick hasn't mapped yet ──
        cur.execute('SELECT id, name FROM players')
        name_to_pid = {normalize_name(name): pid for pid, name in cur.fetchall() if name}
        # ────────────────────────────────────────────────────────────────
    records = []
    matched_by_id = 0
    matched_by_name = 0
    unmatched = 0
    for _, row in df.iterrows():
        fg_id = safe_int(row.get('IDfg'))
        pid = fg_to_pid.get(fg_id)
        if pid:
            matched_by_id += 1
        else:
            # ── v1.5: name fallback ──
            fg_name = row.get('Name') or row.get('name') or ''
            norm = normalize_name(fg_name)
            pid = name_to_pid.get(norm)
            if pid:
                matched_by_name += 1
            else:
                unmatched += 1
                continue
        records.append((
            pid, CURRENT_SEASON,
            safe_int(row.get('G')), safe_int(row.get('GS')),
            safe_int(row.get('W')), safe_int(row.get('L')),
            safe_int(row.get('SV')), safe_int(row.get('HLD')),
            safe_int(row.get('QS')), safe_float(row.get('IP')),
            safe_int(row.get('H')), safe_int(row.get('ER')),
            safe_int(row.get('BB')), safe_int(row.get('SO')),
            safe_int(row.get('HR')),
            safe_float(row.get('ERA')), safe_float(row.get('WHIP')),
            safe_float(row.get('K/9')), safe_float(row.get('BB/9')),
            safe_float(row.get('K%')), safe_float(row.get('BB%')),
            safe_float(row.get('K-BB%')),
            safe_float(row.get('FIP')), safe_float(row.get('xFIP')),
            safe_float(row.get('SIERA')), safe_float(row.get('xERA')),
            safe_float(row.get('WAR')),
            safe_float(row.get('FBv')), safe_float(row.get('maxFBv')),
            safe_float(row.get('SpinRate')),
            safe_float(row.get('Barrel%')), safe_float(row.get('HardHit%')),
            safe_float(row.get('xwOBA')), safe_float(row.get('xBA')),
            safe_float(row.get('CSW%')), safe_float(row.get('SwStr%')),
            safe_float(row.get('O-Swing%')), safe_float(row.get('Zone%')),
            'fangraphs',
        ))
    # ── v1.5: log match breakdown ──
    log.info(f'  FG pitcher matches: {matched_by_id} by ID, {matched_by_name} by name, {unmatched} unmatched')
    if not records:
        return 0
    log.info(f'  Writing {len(records)} pitcher rows')
    with conn.cursor() as cur:
        player_ids_in_records = [r[0] for r in records]
        cur.execute('DELETE FROM pitcher_stats WHERE season=%s AND player_id=ANY(%s) AND data_source LIKE %s',
                    (CURRENT_SEASON, player_ids_in_records, '%fangraphs%'))
        execute_batch(cur, """
            INSERT INTO pitcher_stats (player_id, season, games, games_started, wins, losses,
                saves, holds, quality_starts, innings_pitched, hits_allowed, earned_runs,
                walks_allowed, strikeouts_pitched, homeruns_allowed,
                era, whip, k_per_9, bb_per_9, k_rate, bb_rate, k_minus_bb,
                fip, x_fip, siera, x_era, war, avg_fastball_velo, max_fastball_velo, spin_rate,
                barrel_pct_against, hard_hit_pct_against, xwoba_against, xba_against,
                csw_pct, sw_strike_pct, chase_pct_induced, zone_pct, data_source, fetched_at)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
                    %s,%s,%s,%s,%s,%s,%s,
                    %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW())
        """, records)
    conn.commit()
    return len(records)
```

Apply the **same pattern** to `pull_fangraphs_batters(conn)`:

1. After the existing `cur.execute('SELECT fangraphs_id, player_id ...')`,
   add:
   ```python
   cur.execute('SELECT id, name FROM players')
   name_to_pid = {normalize_name(name): pid for pid, name in cur.fetchall() if name}
   ```

2. In the iterrows loop, replace:
   ```python
   pid = fg_to_pid.get(fg_id)
   if not pid: continue
   ```
   with:
   ```python
   pid = fg_to_pid.get(fg_id)
   if not pid:
       fg_name = row.get('Name') or row.get('name') or ''
       norm = normalize_name(fg_name)
       pid = name_to_pid.get(norm)
       if not pid:
           continue
   ```

3. Add match breakdown logging if you want symmetry with the pitcher
   version (optional).

### Step 5 — Push to GitHub

```bash
git add .
git commit -m "v1.5: Yahoo stats pipeline + FanGraphs name-fallback"
git push origin main
```

The new workflow file (`pull-yahoo-stats.yml`) will hit the Replit
OAuth scope wall again (same issue from the v1.4 deploy). Use the
same workaround:

```bash
git rm --cached .github/workflows/pull-yahoo-stats.yml
git commit -m "Temp: exclude workflow file (Replit OAuth lacks workflow scope)"
git push origin main
```

Then create the workflow file via GitHub web UI:
1. Go to https://github.com/baseballshoe/Joyful-Draft-HQ
2. Add file → Create new file
3. Filename: `.github/workflows/pull-yahoo-stats.yml`
4. Paste contents from the v1.5 zip
5. Commit directly to main

Then sync back to Replit:
```bash
git pull origin main
```

### Step 6 — Trigger Pull Yahoo stats workflow

GitHub → Actions → "Pull Yahoo stats" → Run workflow → main

Expected log:
```
Starting Yahoo stats pull
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Yahoo stats pull complete
  Total players seen:      ~1,400
  Matched to our DB:       ~1,380
  Unmatched (skipped):     ~20
  Pitcher rows written:    ~530
  Batter rows written:     ~850
  QS total across league:  ~140
  Elapsed:                 ~30s
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

If you see "Yahoo auth issue (silent degradation)" — your token
expired between when v1.4 deployed and now. Visit `/yahoo` in the
running app, re-authenticate, and re-run the workflow.

### Step 7 — Trigger Pull stats (with FG name-fallback) again

GitHub → Actions → "Pull stats" → Run workflow → main

Look for the new log line:
```
  FG pitcher matches: ~140 by ID, ~30 by name, ~20 unmatched
```

The "by name" count = pitchers FG had that Chadwick hadn't mapped.
Those are the players who previously had no FG row in our DB. Now
they get full FG sabermetrics.

### Step 8 — Smoke tests

```bash
PGURL='postgresql://neondb_owner:npg_t8Ihb0ixUgGd@ep-billowing-haze-akye78bh.c-3.us-west-2.aws.neon.tech/neondb?sslmode=require'

# 1. Verify Yahoo data flowed for Messick (the test case)
psql "$PGURL" -c "
  SELECT data_source, games_started, innings_pitched, era, whip,
         quality_starts, strikeouts_pitched, walks_allowed
  FROM pitcher_stats
  WHERE player_id = 284 AND season = 2026
  ORDER BY data_source;
"
# Expect 3+ rows now: yahoo (with QS!), mlb-stats-api, savant,
# possibly fangraphs (if name-fallback caught him).

# 2. League QS leaders from Yahoo specifically
psql "$PGURL" -c "
  SELECT p.name, ps.quality_starts, ps.games_started, ps.era, ps.whip
  FROM pitcher_stats ps
  JOIN players p ON p.id = ps.player_id
  WHERE ps.season = 2026 AND ps.data_source = 'yahoo'
    AND ps.quality_starts >= 1
  ORDER BY ps.quality_starts DESC LIMIT 15;
"
# Compare to your Yahoo league page's QS leaderboard. Should match
# exactly (or within 1 if a game finished between when our nightly
# ran and when you check).

# 3. Verify FG name-fallback caught Messick
psql "$PGURL" -c "
  SELECT data_source, fip, x_fip, war
  FROM pitcher_stats
  WHERE player_id = 284 AND season = 2026 AND data_source = 'fangraphs';
"
# Expect: row with FIP / xFIP / WAR populated
# (if FG had him in their leaderboard at all)

# 4. Spot-check overall Yahoo coverage
psql "$PGURL" -c "
  SELECT
    (SELECT COUNT(*) FROM pitcher_stats WHERE season=2026 AND data_source='yahoo') AS yahoo_pitchers,
    (SELECT COUNT(*) FROM batter_stats WHERE season=2026 AND data_source='yahoo') AS yahoo_batters;
"
# Expect: ~530 pitchers, ~850 batters.
```

### Step 9 — Coach test

Ask Coach the same Messick question:
> what about parker messick

Expected response qualities:
- Cites real numbers including QS — "5 QS through 6 starts" (or whatever
  Yahoo says)
- Brief "limited data" caveat woven in (one phrase)
- Confident recommendation
- Tone matches v1.4 personality (tease-don't-lecture)

Try a prospect-stash question:
> any prospects worth stashing on the wire?

Now Coach can see all rosterable players, including AAA-callup
candidates. Should give actual recommendations, not "I don't see any."

## Failure modes & rollback

**Yahoo auth fails during nightly:**
- Script logs warning, exits 0
- Coach falls back to MLB Stats API + FG + Savant for that night
- User re-auths via `/yahoo` page, next nightly recovers

**Yahoo pulls fail repeatedly:**
- Disable workflow temporarily: GitHub → Actions → Pull Yahoo stats →
  ··· → Disable workflow
- Other sources keep flowing
- Investigate offline

**Want to revert v1.5 entirely:**
- `git revert` the v1.5 commits
- Push
- Workflow files removed (or just disable them in Actions UI)
- Back to v1.4 behavior

## Cost impact

- Yahoo nightly: ~30-60 seconds, 100-150 API calls (well within Yahoo's
  ~40k/day quota)
- Coach context: same cost as v1.4 (multi-source merge already there)
- GitHub Actions: ~1 minute of runner time per nightly = negligible

## What's still deferred

- Storing `yahoo_player_key` in `player_ids` for direct lookup (currently
  matching by name+team works fine for ~99% of players; this would
  bring it to 100%)
- Multi-user support — v1.5 single-user (`id=1` in yahoo_tokens). Phase
  3 multi-user requires looping over user IDs.
- Yahoo commercial license application (required before charging users)
- Phase 3 data licensing: SportsDataIO swap for non-Yahoo sources
- Question-intent detection in `categorizer.ts`
- Admin dashboard, 6 new pages
